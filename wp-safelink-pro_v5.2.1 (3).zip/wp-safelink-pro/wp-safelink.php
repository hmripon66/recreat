<?php
/*
Plugin Name: WP Safelink (PRO Version)
Plugin URI: https://themeson.com
Description: Converter Your Download Link to Adsense. <strong>Requires ionCube Loader 14.0.0 and PHP v8.3</strong>
Version: 5.2.1
Author: ThemesON
Author URI:  https://themeson.com
*/

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if ( ! extension_loaded( 'ionCube Loader' ) || version_compare( phpversion( 'ionCube Loader' ), '14.0.0', '<' ) ) {
	$ioncube_version = phpversion( 'ionCube Loader' ) != "" ? phpversion( 'ionCube Loader' ) : "Ioncube not installed";
    deactivate_plugins(plugin_basename(__FILE__));

	wp_die( 'Plugin WP Safelink (Adsense Version) requires <strong>ionCube Loader 14.0.0</strong> and your ionCube version is <strong>' . $ioncube_version . '</strong>. Please contact your hosting provider to upgrade your ionCube version.' );
}

/**
 * Retreive plugin url
 *
 * @access  public
 * @return  string  Plugin URL with plugin slug
 * @since   1.0.0
 */
function wpsafelink_plugin_url()
{
    return untrailingslashit(plugins_url('/', __FILE__));
}

/**
 * Retreive plugin path directory
 *
 * @access  public
 * @return  string  Plugin directory
 * @since   1.0.0
 */
function wpsafelink_plugin_path()
{
    return __DIR__;
}

/**
 * Retreive plugin file
 *
 * @access  public
 * @return  string  Plugin file
 * @since   1.0.0
 */
function wpsafelink_plugin_file()
{
    return __FILE__;
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'wpsafelink_settings_links');
function wpsafelink_settings_links($links)
{
    $plugin_links = array(
        '<a href="' . admin_url('admin.php?page=wpsafelink') . '">' . __('Settings', 'wp-safelink') . '</a>',
    );

    return array_merge($plugin_links, $links);
}

register_activation_hook(__FILE__, 'wpsafelink_revamp_activation');
function wpsafelink_revamp_activation()
{
    // Set flag to redirect to wizard on first admin page load
    set_transient('wpsafelink_activation_redirect', true, 30);
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'wpsafelink';
    $sql = "CREATE TABLE $table_name (
		ID bigint(0) NOT NULL AUTO_INCREMENT, 
		date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL, 
		date_view datetime DEFAULT '0000-00-00 00:00:00' NOT NULL, 
		date_click datetime DEFAULT '0000-00-00 00:00:00' NOT NULL, 
		safe_id varchar(8) NOT NULL,
		link longtext NOT NULL,
		view bigint(0) NOT NULL,
		click bigint(0) NOT NULL,
		UNIQUE KEY id (ID)
	) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    wpsafelink_migrate();

    $upload_dir = wp_get_upload_dir();
    $tmp = $upload_dir['basedir'] . '/wpsaf.script.js';
    if (file_exists($tmp)) {
        $data = file_get_contents($tmp);
        $cached = wpsafelink_plugin_path() . '/assets/wpsaf.script.js';

        file_put_contents($cached, $data);
        unlink($tmp);
    }
}

function wpsafelink_migrate()
{
    $new_options = wpsafelink_options();
    if (empty($new_options)) {
        $old_options = get_option('wpsaf_options');
        if (!empty($old_options)) {
            $old_options = json_decode($old_options, true);

            $new_options['permalink'] = $old_options['permalink'];
            $new_options['permalink_parameter'] = $old_options['permalink1'];
            $new_options['content_method'] = $old_options['content'] == 0 ? 'random' : 'selected';
            $new_options['content_ids'] = $old_options['contentid'];
            $new_options['time_delay'] = $old_options['delay'];
            $new_options['time_delay_message'] = $old_options['delaytext'];
            $new_options['action_button'] = $old_options['action_type'];
            $new_options['action_button_image_1'] = $old_options['image4'];
            $new_options['action_button_image_2'] = $old_options['image1'];
            $new_options['action_button_image_3'] = $old_options['image2'];
            $new_options['action_button_image_4'] = $old_options['image3'];
            $new_options['action_button_text_1'] = $old_options['button4'];
            $new_options['action_button_text_2'] = $old_options['button1'];
            $new_options['action_button_text_3'] = $old_options['button2'];
            $new_options['action_button_text_4'] = $old_options['button3'];
            $new_options['captcha_enable'] = $old_options['recaptcha_enable'] == 1 ? 'yes' : 'no';
            $new_options['captcha'] = $old_options['captcha_provider'];
            $new_options['recaptcha_site_key'] = $old_options['recaptcha_site_key'];
            $new_options['recaptcha_secret_key'] = $old_options['recaptcha_secret_key'];
            $new_options['recaptcha_label'] = $old_options['recaptcha_text'];
            $new_options['hcaptcha_site_key'] = $old_options['hcaptcha_site_key'];
            $new_options['hcaptcha_secret_key'] = $old_options['hcaptcha_secret_key'];
            $new_options['hcaptcha_label'] = $old_options['hcaptcha_text'];
            $new_options['advertisement_top_1'] = $old_options['ads1'];
            $new_options['advertisement_top_2'] = $old_options['ads1_after'];
            $new_options['advertisement_top_3'] = $old_options['ads2_before'];
            $new_options['advertisement_top_4'] = $old_options['ads2'];
            $new_options['anti_adblock'] = $old_options['adb'] == 1 ? 'yes' : 'no';
            $new_options['anti_adblock_header_1'] = $old_options['adb1'];
            $new_options['anti_adblock_header_2'] = $old_options['adb2'];
            $new_options['adlinkfly_url'] = $old_options['adlinkfly_url'];
            $new_options['auto_save_safelink'] = $old_options['autosave'] == 1 ? 'yes' : 'no';
            $new_options['auto_convert_link'] = $old_options['autoconvert'] == 1 ? 'yes' : 'no';
            $new_options['auto_convert_link_method'] = $old_options['autoconvertmethod'];
            $new_options['domain_list'] = $old_options['domain'] . $old_options['exclude_domain'];

            update_option('wpsafelink_settings', $new_options);
        }
    }
}

function wpsafelink_options()
{
    return get_option('wpsafelink_settings', array());
}

require_once wpsafelink_plugin_path() . '/vendor/simple_html_dom.php';
require_once wpsafelink_plugin_path() . '/vendor/plugin-update-checker/plugin-update-checker.php';
require_once wpsafelink_plugin_path() . '/vendor/autoload.php';
require_once wpsafelink_plugin_path() . '/includes/class-core.php';
require_once wpsafelink_plugin_path() . '/includes/class-ajax.php';
require_once wpsafelink_plugin_path() . '/includes/class-settings.php';
require_once wpsafelink_plugin_path() . '/includes/class-functions.php';

if (file_exists(wpsafelink_plugin_path() . '/wp-safelink.pro.php')) {
    require(wpsafelink_plugin_path() . '/wp-safelink.pro.php');
}