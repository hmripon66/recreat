<?php
/**
 * WP Safelink Setup Wizard - License Activation Step
 * 
 * @package WP Safelink
 * @since 5.1.3
 */

if (!defined('ABSPATH')) {
    exit;
}

global $wpsafelink_core;
$domain = str_replace(['https://', 'http://'], '', home_url());
$license = $wpsafelink_core->license();
$check_license = $license['success'] ?? false;

?>

<div class="wizard-step-license">
    <div class="step-header">
        <h2>🔐 Activate Your License</h2>
        <p class="step-intro">
            Enter your WP Safelink license key to unlock all features and begin the setup process.
            Your license key was provided when you purchased WP Safelink.
        </p>
    </div>

    <?php if ($check_license): ?>
    <!-- License Already Activated -->
    <div class="license-activated-panel">
        <div class="activation-success">
            <div class="success-icon">✅</div>
            <h3>License Successfully Activated!</h3>
            <p>Your WP Safelink license is active and ready to use.</p>
        </div>
        
        <div class="license-details">
            <div class="detail-row">
                <label>Domain:</label>
                <span class="domain-name"><?php echo esc_html($domain); ?></span>
            </div>
            <div class="detail-row">
                <label>License Key:</label>
                <span class="license-key"><?php echo esc_html($wpsafelink_core->license('key')); ?></span>
            </div>
            <div class="detail-row">
                <label>Status:</label>
                <span class="status-active">Active & Valid</span>
            </div>
        </div>

        <div class="activation-actions">
            <button type="button" class="button button-secondary" onclick="changeLicense()">
                Change License
            </button>
            <a href="<?php echo admin_url('admin.php?page=wpsafelink&wizard_step=template'); ?>" 
               class="button button-primary">
                Continue to Template Selection →
            </a>
        </div>
    </div>

    <?php else: ?>
    <!-- License Activation Form -->
    <div class="license-activation-panel">
        <form id="license-activation-form" method="POST">
            <?php wp_nonce_field('wpsafelink_license_activation', 'license_nonce'); ?>
            <input type="hidden" name="page" value="wpsafelink">
            <input type="hidden" name="action" value="license">
            <input type="hidden" name="wizard_step" value="license">

            <div class="form-section">
                <div class="form-row">
                    <label for="wpsafelink_domain" class="form-label">
                        <strong>Domain</strong>
                        <span class="description">Your website domain (automatically detected)</span>
                    </label>
                    <input name="wpsafelink_domain" type="text" id="wpsafelink_domain" 
                           value="<?php echo esc_attr($domain); ?>" 
                           class="regular-text" autocomplete="off" readonly style="width: 100%;">
                </div>

                <div class="form-row">
                    <label for="wpsafelink_license" class="form-label">
                        <strong>License Key *</strong>
                        <span class="description">Enter your WP Safelink license key</span>
                    </label>
                    <input name="wpsafelink_license" type="text" id="wpsafelink_license" 
                           class="regular-text license-input" autocomplete="off" 
                           placeholder="Enter your license key..." required>
                    <div class="license-validation-feedback" id="license-feedback"></div>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" id="activate-license-btn" class="button button-primary button-large">
                    <span class="btn-text">Validate License</span>
                    <span class="btn-spinner" style="display: none;">
                        <span class="spinner is-active"></span> Validating...
                    </span>
                </button>
                
                <p class="license-help">
                    Don't have a license? 
                    <a href="https://themeson.com/member/" target="_blank" class="license-link">
                        Get your license key →
                    </a>
                </p>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <!-- License Information Panel -->
    <div class="license-info-panel">
        <h4>📋 License Information</h4>
        <div class="info-grid">
            <div class="info-item">
                <strong>What is a license key?</strong>
                <p>Your license key validates your purchase and enables all WP Safelink features.</p>
            </div>
            <div class="info-item">
                <strong>Where to find it?</strong>
                <p>Check your purchase receipt email or visit your account at themeson.com</p>
            </div>
            <div class="info-item">
                <strong>Need help?</strong>
                <p>Contact our support team if you can't locate your license key.</p>
            </div>
        </div>
    </div>
</div>

<!-- License step styles moved to assets/css/wizard.css -->

<script>
jQuery(document).ready(function($) {
    let isValidating = false;
    
    // License activation form submission
    $('#license-activation-form').on('submit', function(e) {
        e.preventDefault();
        
        if (isValidating) return;
        
        const licenseKey = $('#wpsafelink_license').val().trim();
        
        if (!licenseKey) {
            showFeedback('Please enter your license key.', 'error');
            return;
        }
        
        activateLicense(licenseKey);
    });
    
    // Real-time license key validation
    let validationTimeout;
    $('#wpsafelink_license').on('input', function() {
        const licenseKey = $(this).val().trim();
        
        clearTimeout(validationTimeout);
        
        if (licenseKey.length > 10) {
            validationTimeout = setTimeout(() => {
                validateLicenseFormat(licenseKey);
            }, 500);
        } else {
            clearFeedback();
        }
    });
    
    function validateLicenseFormat(licenseKey) {
        // Basic format validation
        if (licenseKey.length < 10) {
            showFeedback('License key appears too short.', 'error');
        } else if (!/^[A-Za-z0-9\-_]+$/.test(licenseKey)) {
            showFeedback('License key contains invalid characters.', 'error');
        } else {
            showFeedback('License key format looks valid.', 'success');
        }
    }
    
    function activateLicense(licenseKey) {
        isValidating = true;
        
        // Update UI to show validation state
        updateButtonState('validating');
        clearFeedback();
        
        // AJAX license validation
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wpsafelink_validate_license',
                license_key: licenseKey,
                domain: $('#wpsafelink_domain').val(),
                nonce: $('#license_nonce').val()
            },
            timeout: 30000,
            success: function(response) {
                if (response.success) {
                    showFeedback('License activated successfully!', 'success');
                    updateButtonState('success');
                    
                    // Trigger license activation event
                    $(document).trigger('license_activated');
                    
                    // Redirect to next step after short delay
                    setTimeout(() => {
                        window.location.href = '<?php echo admin_url('admin.php?page=wpsafelink&wizard_step=template'); ?>';
                    }, 1500);
                    
                } else {
                    const errorMsg = response.data?.message || 'License validation failed. Please check your license key.';
                    showFeedback(errorMsg, 'error');
                    updateButtonState('error');
                }
            },
            error: function(xhr, status, error) {
                let errorMsg = 'Connection error. Please try again.';
                
                if (status === 'timeout') {
                    errorMsg = 'Request timed out. Please check your connection and try again.';
                }
                
                showFeedback(errorMsg, 'error');
                updateButtonState('error');
            },
            complete: function() {
                isValidating = false;
                
                // Reset button state after delay if there was an error
                setTimeout(() => {
                    if (!$('#license-feedback').hasClass('feedback-success')) {
                        updateButtonState('default');
                    }
                }, 3000);
            }
        });
    }
    
    function updateButtonState(state) {
        const btn = $('#activate-license-btn');
        const btnText = btn.find('.btn-text');
        const btnSpinner = btn.find('.btn-spinner');
        
        btn.removeClass('button-primary button-secondary');
        
        switch (state) {
            case 'validating':
                btn.addClass('button-secondary').prop('disabled', true);
                btnText.hide();
                btnSpinner.show();
                break;
                
            case 'success':
                btn.addClass('button-primary').prop('disabled', true);
                btnText.text('✅ Activated!').show();
                btnSpinner.hide();
                break;
                
            case 'error':
                btn.addClass('button-primary').prop('disabled', false);
                btnText.text('Try Again').show();
                btnSpinner.hide();
                break;
                
            default:
                btn.addClass('button-primary').prop('disabled', false);
                btnText.text('Validate License').show();
                btnSpinner.hide();
                break;
        }
    }
    
    function showFeedback(message, type) {
        const feedback = $('#license-feedback');
        feedback.removeClass('feedback-success feedback-error')
                .addClass('feedback-' + type)
                .text(message)
                .fadeIn();
    }
    
    function clearFeedback() {
        $('#license-feedback').fadeOut().empty();
    }
    
    // Change license function (for activated licenses)
    window.changeLicense = function() {
        if (confirm('Are you sure you want to change your license? This will deactivate the current license.')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'wpsafelink_change_license',
                    nonce: '<?php echo wp_create_nonce('wpsafelink_change_license'); ?>'
                },
                success: function(response) {
                    location.reload();
                }
            });
        }
    };
});
</script>
