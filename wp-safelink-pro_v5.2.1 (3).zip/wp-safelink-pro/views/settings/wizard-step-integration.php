<?php
/**
 * WP Safelink Setup Wizard - Theme Integration Step
 * 
 * @package WP Safelink
 * @since 5.1.3
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current template
$current_options = wpsafelink_options();
$current_template = $current_options['template'] ?? '';

// Check if integration is actually required
$integration_required_templates = ['template2', 'template3'];
if (!in_array($current_template, $integration_required_templates)) {
    // Redirect to complete step if integration not needed
    echo '<script>window.location.href = "' . admin_url('admin.php?page=wpsafelink&wizard_step=complete') . '";</script>';
    return;
}

// Get theme information
$theme = wp_get_theme();
$theme_root = get_theme_root();
$current_theme = get_stylesheet();

// Check current integration status
// Use the settings instance passed from display_wizard()
$header_integration = $wpsafelink_settings_instance->check_theme_integration('header');
$footer_integration = $wpsafelink_settings_instance->check_theme_integration('footer');

?>

<div class="wizard-step-integration">
    <div class="step-header">
        <h2>🔧 Setup Theme Integration</h2>
        <p class="step-intro">
            <?php echo ucfirst($current_template); ?> requires code integration with your WordPress theme. 
            Follow the steps below to add the required code snippets to your theme files.
        </p>
    </div>

    <!-- Integration Requirements Notice -->
    <div class="integration-notice">
        <div class="notice-icon">⚠️</div>
        <div class="notice-content">
            <h4>Integration Required for <?php echo ucfirst($current_template); ?></h4>
            <p>This template needs special code in your theme's header.php and footer.php files to function properly. 
               Don't worry - we'll guide you through the process step by step.</p>
        </div>
    </div>

    <!-- Integration Cards -->
    <div class="integration-cards">
        <!-- Header Integration Card -->
        <div class="integration-card" id="header-card">
            <div class="card-header">
                <h3>📄 Header Integration</h3>
                <span class="status-indicator" id="header-status">
                    <?php echo $header_integration ? '✅ Detected' : '❌ Required'; ?>
                </span>
            </div>
            
            <div class="card-body">
                <div class="integration-description">
                    <p>Add this code to your theme's header.php file, just before the closing <code>&lt;/head&gt;</code> tag:</p>
                </div>
                
                <div class="code-snippet">
                    <button class="copy-btn" data-copy="header-code">📋 Copy Code</button>
                    <code id="header-code">&lt;?php if(function_exists('newwpsafelink_top'))
                        newwpsafelink_top();?&gt;</code>
                </div>
                
                <div class="integration-steps">
                    <h4>Step-by-Step Instructions:</h4>
                    <ol>
                        <li>
                            <strong>Open Header Editor:</strong>
                            <button class="btn-editor" onclick="openHeaderEditor()">🖊️ Open header.php Editor</button>
                            <span class="step-help">(Opens in new tab)</span>
                        </li>
                        <li><strong>Find Location:</strong> Look for the closing <code>&lt;/head&gt;</code> tag (usually around line 20-30)</li>
                        <li><strong>Paste Code:</strong> Add the copied code just BEFORE the <code>&lt;/head&gt;</code> tag</li>
                        <li><strong>Save Changes:</strong> Click "Update File" in the WordPress editor</li>
                        <li><strong>Return Here:</strong> Come back to this tab and click "Re-check Integration"</li>
                    </ol>
                </div>
                
                <div class="integration-help">
                    <div class="help-item">
                        <strong>File Location:</strong>
                        <code><?php echo $theme_root . '/' . $current_theme . '/header.php'; ?></code>
                    </div>
                    <div class="help-item">
                        <strong>Current Theme:</strong> <?php echo $theme->get('Name'); ?> (<?php echo $current_theme; ?>)
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Integration Card -->
        <div class="integration-card" id="footer-card">
            <div class="card-header">
                <h3>📄 Footer Integration</h3>
                <span class="status-indicator" id="footer-status">
                    <?php echo $footer_integration ? '✅ Detected' : '❌ Required'; ?>
                </span>
            </div>
            
            <div class="card-body">
                <div class="integration-description">
                    <p>Add this code to your theme's footer.php file, just before the closing <code>&lt;/body&gt;</code> tag:</p>
                </div>
                
                <div class="code-snippet">
                    <button class="copy-btn" data-copy="footer-code">📋 Copy Code</button>
                    <code id="footer-code">&lt;?php if(function_exists('newwpsafelink_bottom')) newwpsafelink_bottom();?&gt;</code>
                </div>
                
                <div class="integration-steps">
                    <h4>Step-by-Step Instructions:</h4>
                    <ol>
                        <li>
                            <strong>Open Footer Editor:</strong>
                            <button class="btn-editor" onclick="openFooterEditor()">🖊️ Open footer.php Editor</button>
                            <span class="step-help">(Opens in new tab)</span>
                        </li>
                        <li><strong>Find Location:</strong> Look for the closing <code>&lt;/body&gt;</code> tag (usually at the bottom)</li>
                        <li><strong>Paste Code:</strong> Add the copied code just BEFORE the <code>&lt;/body&gt;</code> tag</li>
                        <li><strong>Save Changes:</strong> Click "Update File" in the WordPress editor</li>
                        <li><strong>Return Here:</strong> Come back to this tab and click "Re-check Integration"</li>
                    </ol>
                </div>
                
                <div class="integration-help">
                    <div class="help-item">
                        <strong>File Location:</strong>
                        <code><?php echo $theme_root . '/' . $current_theme . '/footer.php'; ?></code>
                    </div>
                    <div class="help-item">
                        <strong>Current Theme:</strong> <?php echo $theme->get('Name'); ?> (<?php echo $current_theme; ?>)
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Progress and Actions -->
    <div class="integration-progress">
        <div class="progress-container">
            <div class="progress-bar">
                <div class="progress-fill" id="integration-progress" style="width: <?php echo (($header_integration ? 1 : 0) + ($footer_integration ? 1 : 0)) * 50; ?>%"></div>
            </div>
            <div class="progress-text">
                Integration Progress: <span id="progress-count"><?php echo ($header_integration ? 1 : 0) + ($footer_integration ? 1 : 0); ?></span>/2 completed
            </div>
        </div>
        
        <div class="integration-actions">
            <button class="button button-secondary" onclick="recheckIntegration()" id="recheck-btn">
                🔄 Re-check Integration
            </button>
            <button class="button button-primary" id="next-btn" <?php echo (!$header_integration || !$footer_integration) ? 'disabled' : ''; ?>>
                Continue to Testing →
            </button>
        </div>
    </div>

    <!-- Alternative Methods -->
    <div class="integration-alternatives">
        <details>
            <summary>🔧 Alternative Integration Methods</summary>
            <div class="alternative-content">
                <h4>Manual File Access (Advanced Users)</h4>
                <p>If you prefer to edit files directly via FTP, cPanel File Manager, or other methods:</p>
                
                <div class="alternative-method">
                    <h5>Method 2: FTP/File Manager</h5>
                    <ol>
                        <li>Access your website files via FTP or hosting control panel</li>
                        <li>Navigate to <code>/wp-content/themes/<?php echo $current_theme; ?>/</code></li>
                        <li>Edit <code>header.php</code> and <code>footer.php</code> files</li>
                        <li>Add the code snippets as shown above</li>
                        <li>Save and upload the files</li>
                    </ol>
                </div>
                
                <div class="alternative-method">
                    <h5>Method 3: Child Theme (Recommended for Custom Themes)</h5>
                    <p>If you're using a custom theme, consider creating a child theme to preserve changes during theme updates.</p>
                    <a href="https://developer.wordpress.org/themes/advanced-topics/child-themes/" target="_blank" class="external-link">
                        Learn about child themes →
                    </a>
                </div>
            </div>
        </details>
    </div>

    <!-- Help Section -->
    <div class="integration-help-section">
        <h4>🆘 Need Help?</h4>
        <div class="help-links">
            <a href="https://kb.themeson.com/knowledge-base/integrate-wp-safelink-to-custom-theme" target="_blank" class="help-link">
                📖 Step-by-step tutorial with screenshots
            </a>
            <a href="https://support.themeson.com" target="_blank" class="help-link">
                💬 Get technical support
            </a>
        </div>
        
        <div class="troubleshooting">
            <details>
                <summary>🔍 Troubleshooting Common Issues</summary>
                <div class="troubleshooting-content">
                    <div class="issue">
                        <h5>Integration not detected after adding code?</h5>
                        <ul>
                            <li>Make sure you saved the files after editing</li>
                            <li>Check that the code is exactly as shown (no extra spaces or characters)</li>
                            <li>Verify you're editing the correct theme files</li>
                            <li>Try clearing any caching plugins</li>
                        </ul>
                    </div>
                    
                    <div class="issue">
                        <h5>Can't find the closing tags?</h5>
                        <ul>
                            <li>Use Ctrl+F (Cmd+F on Mac) to search for "&lt;/head&gt;" or "&lt;/body&gt;"</li>
                            <li>The &lt;/head&gt; tag is usually in the top section of header.php</li>
                            <li>The &lt;/body&gt; tag is usually at the very bottom of footer.php</li>
                        </ul>
                    </div>
                    
                    <div class="issue">
                        <h5>Theme editor not available?</h5>
                        <ul>
                            <li>Some hosting providers disable the theme editor for security</li>
                            <li>Use FTP or your hosting control panel's file manager instead</li>
                            <li>Contact your hosting provider if you need help accessing files</li>
                        </ul>
                    </div>
                </div>
            </details>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    let checkingIntegration = false;
    let autoCheckInterval;
    
    // Stop auto-checking when both integrations are complete
    function stopAutoCheck() {
        if (autoCheckInterval) {
            clearInterval(autoCheckInterval);
        }
    }
    
    // Copy to clipboard functionality
    $('.copy-btn').on('click', function() {
        const button = $(this);
        const codeElement = button.siblings('code');
        const code = codeElement.text();
        
        // Copy to clipboard
        if (navigator.clipboard) {
            navigator.clipboard.writeText(code).then(function() {
                showCopyFeedback(button);
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = code;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showCopyFeedback(button);
        }
    });
    
    function showCopyFeedback(button) {
        const originalText = button.text();
        button.text('✅ Copied!').addClass('copied');
        
        setTimeout(() => {
            button.text(originalText).removeClass('copied');
        }, 2000);
    }
    
    // Manual re-check integration
    window.recheckIntegration = function() {
        if (checkingIntegration) return;
        
        checkingIntegration = true;
        $('#recheck-btn').prop('disabled', true).text('🔄 Checking...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wpsafelink_check_integration',
                nonce: '<?php echo wp_create_nonce('wpsafelink_check_integration'); ?>'
            },
            timeout: 10000,
            success: function(response) {
                if (response.success) {
                    updateIntegrationStatus(response.data.header, response.data.footer);
                    
                    if (response.data.completed) {
                        stopAutoCheck();
                        showIntegrationComplete();
                    }
                } else {
                    console.error('Integration check failed:', response.data?.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('Integration check error:', error);
            },
            complete: function() {
                checkingIntegration = false;
                $('#recheck-btn').prop('disabled', false).text('🔄 Re-check Integration');
            }
        });
    };
    
    function updateIntegrationStatus(headerOk, footerOk) {
        // Update status indicators
        $('#header-status').text(headerOk ? '✅ Detected' : '❌ Required');
        $('#footer-status').text(footerOk ? '✅ Detected' : '❌ Required');
        
        // Update progress
        const completed = (headerOk ? 1 : 0) + (footerOk ? 1 : 0);
        $('#progress-count').text(completed);
        $('#integration-progress').css('width', (completed * 50) + '%');
        
        // Update next button
        $('#next-btn').prop('disabled', !(headerOk && footerOk));
        
        // Update card styling
        $('#header-card').toggleClass('integration-complete', headerOk);
        $('#footer-card').toggleClass('integration-complete', footerOk);
    }
    
    function showIntegrationComplete() {
        // Show success message
        if ($('#integration-success').length === 0) {
            const successMessage = $(`
                <div id="integration-success" class="integration-success">
                    <div class="success-icon">🎉</div>
                    <h4>Integration Complete!</h4>
                    <p>Both header and footer integration have been detected successfully. You can now continue to the next step.</p>
                </div>
            `);
            
            $('.integration-progress').prepend(successMessage);
        }
    }
    
    // Next button click handler
    $('#next-btn').on('click', function() {
        if (!$(this).prop('disabled')) {
            window.location.href = '<?php echo admin_url('admin.php?page=wpsafelink&wizard_step=testing'); ?>';
        }
    });
    
    // Auto-check integration every 3 seconds
    autoCheckInterval = setInterval(recheckIntegration, 3000);
    
    // Check initial status
    recheckIntegration();
});

// Theme editor functions
function openHeaderEditor() {
    const currentTheme = '<?php echo $current_theme; ?>';
    const url = `<?php echo admin_url('theme-editor.php'); ?>?file=header.php&theme=${currentTheme}`;
    window.open(url, '_blank');
}

function openFooterEditor() {
    const currentTheme = '<?php echo $current_theme; ?>';
    const url = `<?php echo admin_url('theme-editor.php'); ?>?file=footer.php&theme=${currentTheme}`;
    window.open(url, '_blank');
}
</script>

<style>
/* Additional styles for integration completion */
.integration-card.integration-complete {
    border-color: #00a32a;
    box-shadow: 0 0 0 1px rgba(0, 163, 42, 0.2);
}

.integration-card.integration-complete .card-header {
    background: #d1e7dd;
    border-bottom-color: #badbcc;
}

.integration-success {
    background: #d1e7dd;
    border: 1px solid #badbcc;
    border-radius: 6px;
    padding: 20px;
    text-align: center;
    margin-bottom: 20px;
}

.success-icon {
    font-size: 32px;
    margin-bottom: 10px;
}

.integration-success h4 {
    color: #0f5132;
    margin-bottom: 8px;
}

.integration-success p {
    color: #0f5132;
    margin: 0;
}
</style>