<?php
/**
 * WP Safelink Setup Wizard
 *
 * A comprehensive setup wizard to guide first-time users through WP Safelink configuration
 *
 * @package WP Safelink
 * @since 5.1.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get current wizard step
$wizard_step     = $_GET['wizard_step'] ?? 'license';
$wizard_progress = get_option( 'wpsafelink_wizard_progress', array() );

// Check license status to determine mandatory requirements
global $wpsafelink_core;
$license           = $wpsafelink_core->license();
$license_activated = $license['success'] ?? false;

// Define wizard steps with conditional logic
$wizard_steps = array(
	'license'     => array(
		'title'       => 'Activate Your License',
		'description' => 'Enter your license key to unlock WP Safelink features',
		'icon'        => '🔐',
		'required'    => true,
		'completed'   => $license_activated
	),
	'template'    => array(
		'title'       => 'Choose Your Template',
		'description' => 'Select and configure your safelink page design',
		'icon'        => '🎨',
		'required'    => false,
		'completed'   => isset( $wizard_progress['template'] )
	),
	'integration' => array(
		'title'       => 'Setup Theme Integration',
		'description' => 'Integrate WP Safelink with your WordPress theme',
		'icon'        => '🔧',
		'required'    => false, // Will be determined dynamically based on template
		'completed'   => isset( $wizard_progress['integration'] )
	),
	'testing'     => array(
		'title'       => 'Test Your Setup',
		'description' => 'Generate test links and verify your configuration',
		'icon'        => '🧪',
		'required'    => false,
		'completed'   => isset( $wizard_progress['testing'] )
	)
);

// Determine if integration step should be shown
$current_template                        = wpsafelink_options()['template'] ?? '';
$integration_required                    = in_array( $current_template, [ 'template2', 'template3' ] );
$wizard_steps['integration']['required'] = $integration_required;

// If integration not required and user is on integration step, skip to testing
if ( ! $integration_required && $wizard_step === 'integration' ) {
	$wizard_step = 'testing';
}

// Validate step access (can't access later steps without completing required earlier ones)
if ( ! $license_activated && $wizard_step !== 'license' ) {
	$wizard_step = 'license';
}

?>

<div id="wpsafelink-wizard" class="wrap">
    <h1 class="wp-heading-inline">
		<?php echo get_admin_page_title(); ?> Setup Wizard
        <span class="wizard-version">v<?php echo get_plugin_data( wpsafelink_plugin_file() )['Version']; ?></span>
    </h1>

    <!-- Wizard Progress Bar -->
    <div class="wizard-progress-container">
        <div class="wizard-progress-bar">
			<?php
			$step_number         = 1;
			$current_step_number = 1;

			foreach ( $wizard_steps as $step_key => $step_data ):
				// Skip integration step if not required
				if ( $step_key === 'integration' && ! $integration_required ) {
					continue;
				}

				$is_current    = ( $step_key === $wizard_step );
				$is_completed  = $step_data['completed'];
				$is_accessible = $license_activated || $step_key === 'license';

				if ( $is_current ) {
					$current_step_number = $step_number;
				}

				$step_class = array( 'wizard-step' );
				if ( $is_current ) {
					$step_class[] = 'current';
				}
				if ( $is_completed ) {
					$step_class[] = 'completed';
				}
				if ( ! $is_accessible ) {
					$step_class[] = 'locked';
				}
				?>
                <div class="<?php echo implode( ' ', $step_class ); ?>" data-step="<?php echo $step_key; ?>">
                    <div class="step-info">
                        <div class="step-icon"><?php echo $step_data['icon']; ?></div>
                        <div class="step-title"><?php echo $step_data['title']; ?></div>
                        <div class="step-description"><?php echo $step_data['description']; ?></div>
                    </div>
                </div>
				<?php
				$step_number ++;
			endforeach;
			?>
        </div>

        <div class="wizard-progress-info">
            <span class="progress-text">
                Step <?php echo $current_step_number; ?> of <?php echo count( $wizard_steps ) - ( $integration_required ? 0 : 1 ); ?>
	            <?php if ( ! $license_activated ): ?>
                    <span class="license-required">• License activation required</span>
	            <?php endif; ?>
            </span>

			<?php if ( $license_activated ): ?>
                <div class="wizard-skip-option">
                    <a href="<?php echo admin_url( 'admin.php?page=wpsafelink' ); ?>"
                       class="button button-secondary">
                        Continue to Dashboard
                    </a>
                </div>
			<?php endif; ?>
        </div>
    </div>

    <!-- Wizard Content Area -->
    <div class="wizard-content">
        <div class="wizard-step-content">
			<?php
			// Include the appropriate step file
			switch ( $wizard_step ) {
				case 'license':
					include_once wpsafelink_plugin_path() . '/views/settings/wizard-step-license.php';
					break;

				case 'template':
					include_once wpsafelink_plugin_path() . '/views/settings/wizard-step-template.php';
					break;

				case 'integration':
					if ( $integration_required ) {
						include_once wpsafelink_plugin_path() . '/views/settings/wizard-step-integration.php';
					} else {
						// Redirect to testing step if integration not needed
						echo '<script>window.location.href = "' . admin_url( 'admin.php?page=wpsafelink&wizard_step=testing' ) . '";</script>';
					}
					break;

				case 'testing':
					include_once wpsafelink_plugin_path() . '/views/settings/wizard-step-testing.php';
					break;

				default:
					echo '<div class="notice notice-error"><p>Invalid wizard step.</p></div>';
					break;
			}
			?>
        </div>
    </div>

    <!-- Wizard Navigation -->
</div>

<script>
    jQuery(document).ready(function ($) {
        // Update wizard navigation based on step completion
        function updateWizardNavigation() {
            const licenseActivated = <?php echo $license_activated ? 'true' : 'false'; ?>;
            const currentStep = '<?php echo $wizard_step; ?>';

            // Show/hide next button based on license status
            if (currentStep === 'license' && !licenseActivated) {
                $('#wizard-next-btn').hide();
            } else {
                $('#wizard-next-btn').show();
            }
        }

        updateWizardNavigation();

        // Listen for license activation events
        $(document).on('license_activated', function () {
            $('#wizard-next-btn').show();
            $('.license-required').fadeOut();
            $('.wizard-skip-option').removeClass('hidden');

            // Update progress bar
            $('.wizard-step[data-step="license"]').addClass('completed');
            $('.wizard-step[data-step="license"] .step-number').html('<span class="dashicons dashicons-yes-alt"></span>');
        });
    });
</script>
