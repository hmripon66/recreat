<?php
/**
 * WP Safelink Setup Wizard - Template Selection Step (Using get_general_options)
 * 
 * @package WP Safelink
 * @since 5.1.3
 */

if (!defined('ABSPATH')) {
    exit;
}

// Process form submission first
$form_submitted = false;
$save_success = false;
$save_error = '';

if (isset($_POST['action']) && $_POST['action'] === 'save' && isset($_POST['template_nonce']) && wp_verify_nonce($_POST['template_nonce'], 'wpsafelink_template_save')) {
    $form_submitted = true;
    
    // Get current options
    $current_options = wpsafelink_options();
    
    // Process submitted data
    $post_options = $_POST['wpsafelink'] ?? array();
    
    // Handle checkboxes (they won't be in POST if unchecked)
    $checkbox_fields = ['verification_homepage', 'skip_verification'];
    foreach ($checkbox_fields as $field) {
        if (!isset($post_options[$field])) {
            $post_options[$field] = '0'; // Set to '0' if not checked
        }
    }
    
    // Merge submitted data with current options
    $updated_options = array_merge($current_options, $post_options);
    
    // Save the options
    $save_result = update_option('wpsafelink_settings', $updated_options);
    
    // Check if save was successful
    if ($save_result !== false) {
        $save_success = true;
        
        // Mark template step as completed in wizard progress
        $wizard_progress = get_option('wpsafelink_wizard_progress', array());
        $wizard_progress['template'] = true;
        update_option('wpsafelink_wizard_progress', $wizard_progress);
        
        // Determine next step based on template selection
        $selected_template = $post_options['template'] ?? '';
        $integration_required = in_array($selected_template, ['template2', 'template3']);
        $next_step = $integration_required ? 'integration' : 'testing';
        
        // Small delay to ensure options are saved, then redirect
        echo '<script>
            setTimeout(function() {
                window.location.href = "' . admin_url('admin.php?page=wpsafelink&wizard_step=' . $next_step) . '";
            }, 1000);
        </script>';
        
        // Also add a fallback meta refresh
        echo '<meta http-equiv="refresh" content="2; url=' . admin_url('admin.php?page=wpsafelink&wizard_step=' . $next_step) . '">';
        return;
    } else {
        // Check if the option already exists with the same value (which returns false)
        $current_saved = get_option('wpsafelink_settings', array());
        if ($current_saved === $updated_options) {
            // Options were already the same, treat as success
            $save_success = true;
            
            $selected_template = $post_options['template'] ?? '';
            $integration_required = in_array($selected_template, ['template2', 'template3']);
            $next_step = $integration_required ? 'integration' : 'testing';
            
            echo '<script>window.location.href = "' . admin_url('admin.php?page=wpsafelink&wizard_step=' . $next_step) . '";</script>';
            return;
        } else {
            $save_error = 'Failed to save template configuration. Please try again.';
        }
    }
}

// Get template options using the exact method specified in the task
// Use the settings instance passed from display_wizard()
$template_options = $wpsafelink_settings_instance->get_general_options('templates');

// Get current values
$current_options = wpsafelink_options();

// Template integration warnings
$current_template = $current_options['template'] ?? '';
$integration_required_templates = ['template2', 'template3'];
$integration_required = in_array($current_template, $integration_required_templates);

?>

<div class="wizard-step-template">
    <div class="step-header">
        <h2>🎨 Choose Your Template</h2>
        <p class="step-intro">
            Select and configure your safelink page design. Different templates offer varying levels of customization and features.
        </p>
        
        <?php if ($form_submitted && $save_success): ?>
        <div class="notice notice-success is-dismissible">
            <p><strong>Template configuration saved successfully!</strong> Redirecting to next step...</p>
        </div>
        <?php elseif ($form_submitted && !empty($save_error)): ?>
        <div class="notice notice-error is-dismissible">
            <p><strong>Error:</strong> <?php echo esc_html($save_error); ?></p>
        </div>
        <?php endif; ?>
    </div>

    <form method="POST" action="" id="template-form">
        <?php wp_nonce_field('wpsafelink_template_save', 'template_nonce'); ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="page" value="wpsafelink">
        <input type="hidden" name="wizard_step" value="template">

        <!-- Template Configuration using get_general_options('templates') -->
        <div class="template-configuration-panel">
            <h3>Template Configuration</h3>
            
            <?php
            // Render form fields using the existing template options structure
            foreach ($template_options as $field_id => $field_config) {
                if (isset($field_config['disabled']) && $field_config['disabled']) {
                    continue; // Skip disabled fields
                }

	            // Handle section titles properly (avoid rendering as text input)
	            if ( ! empty( $field_config['type'] ) && $field_config['type'] === 'title' ) {
		            echo '<div class="form-section-title" data-field="' . esc_attr( $field_id ) . '">';
		            if ( ! empty( $field_config['title'] ) ) {
			            echo '<h4>' . esc_html( $field_config['title'] ) . '</h4>';
		            }
		            if ( ! empty( $field_config['description'] ) ) {
			            echo '<p class="section-description">' . wp_kses_post( $field_config['description'] ) . '</p>';
		            }
		            echo '</div>';
		            continue;
	            }

                $field_value = $current_options[$field_id] ?? ($field_config['default'] ?? '');
                $field_name = 'wpsafelink[' . $field_id . ']';

	            echo '<div class="form-field" data-field="' . esc_attr($field_id) . '">';
                echo '<div class="form-row">';

	            // Field label
                if (!empty($field_config['title'])) {
                    echo '<label for="' . esc_attr($field_id) . '" class="form-label">';
                    echo '<strong>' . esc_html($field_config['title']) . '</strong>';
                    if (!empty($field_config['description'])) {
                        echo '<span class="description">' . wp_kses_post($field_config['description']) . '</span>';
                    }
                    echo '</label>';
                }

	            // Field input based on type
                switch ($field_config['type']) {
                    case 'select':
                        echo '<select name="' . esc_attr($field_name) . '" id="' . esc_attr($field_id) . '" class="form-select">';
                        if (!empty($field_config['options'])) {
                            foreach ($field_config['options'] as $option_value => $option_label) {
                                $selected = selected($field_value, $option_value, false);
                                echo '<option value="' . esc_attr($option_value) . '"' . $selected . '>' . esc_html($option_label) . '</option>';
                            }
                        }
                        echo '</select>';
                        break;
                        
                    case 'checkbox':
                        echo '<label class="checkbox-label">';
                        echo '<input type="checkbox" name="' . esc_attr($field_name) . '" id="' . esc_attr($field_id) . '" value="1"' . checked($field_value, '1', false) . '>';
                        if (!empty($field_config['label'])) {
                            echo ' ' . esc_html($field_config['label']);
                        }
                        echo '</label>';
                        break;
                        
                    case 'textarea':
                        echo '<textarea name="' . esc_attr($field_name) . '" id="' . esc_attr($field_id) . '" rows="3" class="form-textarea">' . esc_textarea($field_value) . '</textarea>';
                        break;
                        
                    case 'text':
                    default:
                        $input_class = 'form-input';
                        if ($field_id === 'time_delay') {
                            $input_class .= ' small-text';
                        }
                        echo '<input type="text" name="' . esc_attr($field_name) . '" id="' . esc_attr($field_id) . '" value="' . esc_attr($field_value) . '" class="' . $input_class . '">';
                        
                        // Handle image preview for image fields
                        if (strpos($field_id, 'action_button_image_') === 0 && !empty($field_value)) {
                            echo '<div class="image-preview">';
                            echo '<img src="' . esc_url($field_value) . '" alt="Button Image" style="max-width: 150px; margin-top: 10px;">';
                            echo '</div>';
                        }
                        break;
                }
                
                echo '</div>'; // .form-row
                echo '</div>'; // .form-field
            }
            ?>
            
            <!-- Integration Warning (conditional display) -->
            <?php if ($integration_required): ?>
            <div class="integration-warning" id="integration-warning">
                <div class="warning-icon">⚠️</div>
                <div class="warning-content">
                    <h4>Theme Integration Required</h4>
                    <p>The selected template (<?php echo ucfirst($current_template); ?>) requires code integration with your WordPress theme. You'll be guided through this process in the next step.</p>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Save Configuration -->
        <div class="template-actions">
            <button type="submit" class="button button-primary button-large" id="save-template-btn">
                <span class="btn-text">Save Template Configuration</span>
                <span class="btn-spinner" style="display: none;">
                    <span class="spinner is-active"></span> Saving...
                </span>
            </button>
            
            <p class="template-save-help">
                Your template configuration will be saved and you can continue to the next step.
            </p>
        </div>
    </form>
</div>

<script>
jQuery(document).ready(function($) {
    let isSubmitting = false;
    
    // Form submission - no longer preventing default, allowing normal form submission
    $('#template-form').on('submit', function(e) {
        if (isSubmitting) return false;
        
        isSubmitting = true;
        updateButtonState('saving');
        
        // Allow form to submit normally
        return true;
    });
    
    // Template selection change handler
    $('#template').on('change', function() {
        const selectedTemplate = $(this).val();
        updateTemplateSpecificFields(selectedTemplate);
        updateIntegrationWarning(selectedTemplate);
    });
    
    // Action button type change handler
    $('#action_button').on('change', function() {
        const buttonType = $(this).val();
        updateButtonTypeFields(buttonType);
    });
    
    // Initialize on page load
    const selectedTemplate = $('#template').val();
    const selectedButtonType = $('#action_button').val();
    
    if (selectedTemplate) {
        updateTemplateSpecificFields(selectedTemplate);
        updateIntegrationWarning(selectedTemplate);
    }
    
    if (selectedButtonType) {
        updateButtonTypeFields(selectedButtonType);
    }
    
    function updateTemplateSpecificFields(template) {
        // Hide all template-specific fields first
        $('.form-field[data-field="verification_homepage"]').hide();
        $('.form-field[data-field="skip_verification"]').hide();
        
        // Show fields based on template
        if (template === 'template2') {
            $('.form-field[data-field="verification_homepage"]').show();
        } else if (template === 'template3') {
            $('.form-field[data-field="skip_verification"]').show();
        }
    }
    
    function updateButtonTypeFields(buttonType) {
        // Toggle between image and text button fields
        if (buttonType === 'image') {
            $('.form-field[data-field^="action_button_image_"]').show();
            $('.form-field[data-field^="action_button_text_"]').hide();
        } else {
            $('.form-field[data-field^="action_button_image_"]').hide();
            $('.form-field[data-field^="action_button_text_"]').show();
        }
    }
    
    function updateIntegrationWarning(template) {
        const integrationRequired = ['template2', 'template3'].includes(template);
        
        if (integrationRequired) {
            $('#integration-warning').show();
        } else {
            $('#integration-warning').hide();
        }
    }
    
    function updateButtonState(state) {
        const btn = $('#save-template-btn');
        const btnText = btn.find('.btn-text');
        const btnSpinner = btn.find('.btn-spinner');
        
        btn.removeClass('button-primary button-secondary');
        
        switch (state) {
            case 'saving':
                btn.addClass('button-secondary').prop('disabled', true);
                btnText.hide();
                btnSpinner.show();
                break;
                
            default:
                btn.addClass('button-primary').prop('disabled', false);
                btnText.text('Save Template Configuration').show();
                btnSpinner.hide();
                break;
        }
    }
});
</script>
