<?php
/**
 * WP Safelink Setup Wizard - Link Testing & Completion Step
 * 
 * @package WP Safelink
 * @since 5.1.3
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current configuration
$current_options = wpsafelink_options();
$current_template = $current_options['template'] ?? 'template1';

// Get license information
global $wpsafelink_core;
$license = $wpsafelink_core->license();
$license_activated = $license['success'] ?? false;

// Check integration status for templates that need it
$integration_required_templates = ['template2', 'template3'];
$integration_required = in_array($current_template, $integration_required_templates);
$header_integration = false;
$footer_integration = false;

if ($integration_required) {
    // Use the settings instance passed from display_wizard()
    $header_integration = $wpsafelink_settings_instance->check_theme_integration('header');
    $footer_integration = $wpsafelink_settings_instance->check_theme_integration('footer');
}

// Process link generation if submitted
$generated_link = null;
$generation_error = null;
$target_url = '';

if (isset($_POST['action']) && $_POST['action'] === 'generate_link' && isset($_POST['wpsafelink_link'])) {
    $target_url = sanitize_url($_POST['wpsafelink_link']);
    if (!empty($target_url)) {
        try {
            $generated_link = $wpsafelink_core->postGenerateLink($target_url);
        } catch (Exception $e) {
            $generation_error = 'Failed to generate link: ' . $e->getMessage();
        }
    } else {
        $generation_error = 'Please enter a valid URL.';
    }
}

?>

<div class="wizard-step-testing">
    <!-- Step Header -->
    <div class="step-header">
        <h2>🚀 Test Your Setup</h2>
        <p class="step-intro">
            Generate test links to verify your WP Safelink configuration is working properly, 
            then review your setup summary before completing the wizard.
        </p>
    </div>

    <!-- Setup Summary Card -->
    <div class="setup-summary-card">
        <h3>📋 Configuration Summary</h3>
        
        <div class="summary-grid">
            <!-- License Status -->
            <div class="summary-item">
                <div class="summary-icon">🔐</div>
                <div class="summary-content">
                    <h4>License</h4>
                    <span class="summary-status <?php echo $license_activated ? 'success' : 'error'; ?>">
                        <?php echo $license_activated ? '✅ Activated' : '❌ Not Activated'; ?>
                    </span>
                </div>
            </div>

            <!-- Template Configuration -->
            <div class="summary-item">
                <div class="summary-icon">🎨</div>
                <div class="summary-content">
                    <h4>Template</h4>
                    <span class="summary-value"><?php echo ucfirst($current_template); ?></span>
                    <small><?php echo esc_html($current_options['time_delay'] ?? '5'); ?>s delay</small>
                </div>
            </div>

            <!-- Integration Status -->
            <?php if ($integration_required): ?>
            <div class="summary-item">
                <div class="summary-icon">🔧</div>
                <div class="summary-content">
                    <h4>Theme Integration</h4>
                    <div class="integration-summary">
                        <span class="integration-status <?php echo $header_integration ? 'success' : 'warning'; ?>">
                            <?php echo $header_integration ? '✅' : '⚠️'; ?> Header
                        </span>
                        <span class="integration-status <?php echo $footer_integration ? 'success' : 'warning'; ?>">
                            <?php echo $footer_integration ? '✅' : '⚠️'; ?> Footer
                        </span>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Button Configuration -->
            <div class="summary-item">
                <div class="summary-icon">🎯</div>
                <div class="summary-content">
                    <h4>Button Style</h4>
                    <span class="summary-value"><?php echo ucfirst($current_options['action_button'] ?? 'button'); ?> buttons</span>
                </div>
            </div>
        </div>

        <?php if (!$license_activated || ($integration_required && (!$header_integration || !$footer_integration))): ?>
        <div class="summary-warnings">
            <h4>⚠️ Configuration Issues</h4>
            <ul>
                <?php if (!$license_activated): ?>
                <li>License is not activated - some features may not work properly</li>
                <?php endif; ?>
                <?php if ($integration_required && (!$header_integration || !$footer_integration)): ?>
                <li>Theme integration is incomplete - safelinks may not display correctly</li>
                <?php endif; ?>
            </ul>
            <p>These issues should be resolved for optimal functionality.</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- Link Testing Section -->
    <div class="link-testing-section">
        <h3>🔗 Test Link Generation</h3>
        <p class="testing-intro">
            Generate a test safelink to verify your configuration is working correctly.
        </p>

        <!-- Link Generation Form -->
        <form method="POST" action="" id="link-generation-form" class="testing-form">
            <?php wp_nonce_field('wpsafelink_generate_test_link', 'test_link_nonce'); ?>
            <input type="hidden" name="action" value="generate_link">
            <input type="hidden" name="wizard_step" value="testing">

            <div class="form-section">
                <div class="url-input-section">
                    <label for="wpsafelink_link" class="form-label">
                        <strong>Target URL</strong>
                        <span class="description">Enter the URL you want to protect with WP Safelink</span>
                    </label>
                    
                    <div class="url-input-wrapper">
                        <input type="url" 
                               name="wpsafelink_link" 
                               id="wpsafelink_link"
                               class="url-input" 
                               placeholder="https:///download.zip"
                               value="<?php echo esc_attr($target_url); ?>"
                               required>
                        <button type="submit" class="button button-primary generate-btn" id="generate-btn">
                            <span class="btn-text">Generate Safelink</span>
                            <span class="btn-spinner" style="display: none;">
                                <span class="spinner is-active"></span> Generating...
                            </span>
                        </button>
                    </div>
                </div>

                <!-- Quick URL Suggestions -->
                <div class="quick-suggestions">
                    <h4>📌 Quick Test URLs</h4>
                    <div class="suggestion-buttons">
                        <button type="button" class="suggestion-btn" data-url="https://themeson.com/example.pdf">
                            📄 Document Example
                        </button>
                        <button type="button" class="suggestion-btn"
                                data-url="https://demo-movie.themeson.com/movies/tt26743210/">
                            📦 Movie Release
                        </button>
                        <button type="button" class="suggestion-btn" data-url="https://www.internetdownloadmanager.com/download.html">
                            💾 Software Download
                        </button>
                        <button type="button" class="suggestion-btn" data-url="https://file-examples.com/wp-content/storage/2017/11/file_example_MP3_5MG.mp3">
                            🎵 Media File
                        </button>
                    </div>
                </div>
            </div>
        </form>

        <!-- Generation Results -->
        <?php if ($generated_link || $generation_error): ?>
        <div class="generation-results">
            <?php if ($generation_error): ?>
            <!-- Error Display -->
            <div class="result-error">
                <div class="error-icon">❌</div>
                <div class="error-content">
                    <h4>Link Generation Failed</h4>
                    <p><?php echo esc_html($generation_error); ?></p>
                    <button type="button" class="button button-secondary" onclick="clearResults()">
                        Try Again
                    </button>
                </div>
            </div>
            <?php else: ?>
            <!-- Success Display -->
            <div class="result-success">
                <div class="success-content">
                    <h4>Safelink Generated Successfully!</h4>
                    
                    <div class="link-results">
                        <!-- Original URL -->
                        <div class="link-item">
                            <label class="link-label">Original URL:</label>
                            <div class="link-value">
                                <code class="link-code"><?php echo esc_html($target_url); ?></code>
                                <a href="<?php echo esc_url($target_url); ?>" target="_blank" class="link-action">
                                    🔗 Open Original
                                </a>
                            </div>
                        </div>

                        <!-- Generated Safelink -->
                        <div class="link-item">
                            <label class="link-label">Generated Safelink:</label>
                            <div class="link-value">
                                <code class="link-code"><?php echo esc_html($generated_link['generated3'] ?? ''); ?></code>
                                <div class="link-actions">
                                    <button type="button" class="copy-btn"
                                            data-copy="<?php echo esc_attr( $generated_link['generated3'] ?? '' ); ?>">
                                        📋 Copy
                                    </button>
                                    <a href="<?php echo esc_url( $generated_link['generated3'] ?? '' ); ?>"
                                       target="_blank" class="link-action">🚀 Test Safelink</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Testing Instructions -->
                    <div class="testing-instructions">
                        <h5>🧪 Testing Instructions:</h5>
                        <ol>
                            <li>Click "Test Safelink" to open your generated link in a new tab</li>
                            <li>Verify the safelink page loads with your selected template design</li>
                            <li>Check that the countdown timer works (<?php echo esc_html($current_options['time_delay'] ?? '5'); ?> seconds)</li>
                            <li>Ensure the download button appears after the countdown</li>
                            <li>Confirm clicking the download button redirects to the original URL</li>
                        </ol>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Complete Setup -->
    <div class="action-card primary">
        <div class="action-icon">🚀</div>
        <h4>Complete Setup</h4>
        <p>Finish the wizard and go to the main WP Safelink dashboard.</p>
        <a href="<?php echo admin_url( 'admin.php?page=wpsafelink' ); ?>" class="button button-primary">
            Continue to Dashboard
        </a>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    let isGenerating = false;
    
    // Quick suggestion buttons
    $('.suggestion-btn').on('click', function() {
        const url = $(this).data('url');
        $('#wpsafelink_link').val(url);
    });
    
    // Form submission
    $('#link-generation-form').on('submit', function(e) {
        e.preventDefault();
        
        if (isGenerating) return;
        
        generateTestLink();
    });
    
    // Copy to clipboard functionality
    $('.copy-btn').on('click', function() {
        const button = $(this);
        const textToCopy = button.data('copy');
        
        if (navigator.clipboard) {
            navigator.clipboard.writeText(textToCopy).then(function() {
                showCopyFeedback(button);
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = textToCopy;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showCopyFeedback(button);
        }
    });
    
    function showCopyFeedback(button) {
        const originalText = button.text();
        button.text('✅ Copied!').addClass('copied');
        
        setTimeout(() => {
            button.text(originalText).removeClass('copied');
        }, 2000);
    }
    
    function generateTestLink() {
        isGenerating = true;
        
        // Update button state
        updateButtonState('generating');
        
        // Get form data and submit
        const form = document.getElementById('link-generation-form');
        const formData = new FormData(form);
        
        // Submit form normally for now (could be AJAX in future)
        form.submit();
    }
    
    function updateButtonState(state) {
        const btn = $('#generate-btn');
        const btnText = btn.find('.btn-text');
        const btnSpinner = btn.find('.btn-spinner');
        
        btn.removeClass('button-primary button-secondary');
        
        switch (state) {
            case 'generating':
                btn.addClass('button-secondary').prop('disabled', true);
                btnText.hide();
                btnSpinner.show();
                break;
                
            case 'success':
                btn.addClass('button-primary').prop('disabled', false);
                btnText.text('Generate Another Link').show();
                btnSpinner.hide();
                break;
                
            default:
                btn.addClass('button-primary').prop('disabled', false);
                btnText.text('Generate Safelink').show();
                btnSpinner.hide();
                break;
        }
    }
    
    // Clear results function
    window.clearResults = function() {
        $('.generation-results').hide();
        $('#wpsafelink_link').val('').focus();
        updateButtonState('default');
    };
    
    // Scroll to form function
    window.scrollToForm = function() {
        $('#wpsafelink_link').focus();
        $('html, body').animate({
            scrollTop: $('.link-testing-section').offset().top - 50
        }, 500);
    };
    
    // If we have generation results, update button state
    <?php if ($generated_link): ?>
    updateButtonState('success');
    <?php endif; ?>
    
    // Auto-focus URL input on load
    $('#wpsafelink_link').focus();
});
</script>