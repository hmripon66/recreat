<?php
/**
 * Admin View: Section - WP Safelink License Status
 *
 * @package WP Safelink
 * @since 5.2.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( $formatted_data['success'] ) {
	$icon       = 'dashicons-yes-alt';
	$icon_color = '#46b450';
} else {
	$icon       = 'dashicons-warning';
	$icon_color = '#dc3232';
}
?>
    <tr>
        <td colspan="3" class="load_status"
            style="background: #f7f7f7; border-left: 4px solid <?php echo $icon_color; ?>;">
            <div style="display:flex;justify-content: center;align-items: center; padding: 8px;">
                <span class="dashicons <?php echo $icon; ?>"
                      style="color: <?php echo $icon_color; ?>; margin-right: 8px; font-size: 20px;"></span>
                <span style="font-size: 14px; font-weight: 600; color: #333;"><?php echo $formatted_data['message']; ?></span>
            </div>
        </td>
    </tr>
<?php
if ( $formatted_data['success'] ) {
	$row_count = 0;
	foreach ( $formatted_data['result'] as $title => $value ) {
		$row_count ++;
		$row_bg = ( $row_count % 2 == 0 ) ? '#f9f9f9' : '#fff';

		// Format title for display
		$display_title = str_replace( '_', ' ', $title );
		$display_title = ucwords( $display_title );

		// Special formatting for certain fields
		if ( $title == 'license_key' ) {
			$display_title = 'License Key';
		} else if ( $title == 'last_check' ) {
			$display_title = 'Last Validation';
		} else if ( $title == 'response_time' ) {
			$display_title = 'Response Time';
		}

		// Determine status class and styling
		$class      = 'yes';
		$mark_style = '';

		if ( $title == 'status' ) {
			if ( $value == 'active' ) {
				$mark_style = 'background: #7ad03a; color: #fff; padding: 4px 10px; border-radius: 3px; font-weight: 600; text-transform: uppercase; font-size: 11px;';
			} else {
				$class      = 'no';
				$mark_style = 'background: #e74c3c; color: #fff; padding: 4px 10px; border-radius: 3px; font-weight: 600; text-transform: uppercase; font-size: 11px;';
			}
		} else if ( $title == 'response_time' ) {
			// Parse response time value
			$time_value = intval( str_replace( 'ms', '', $value ) );
			if ( $time_value > 1000 ) {
				$class      = 'no';
				$mark_style = 'background: #e74c3c; color: #fff; padding: 4px 10px; border-radius: 3px; font-weight: 600;';
			} else {
				$mark_style = 'background: #7ad03a; color: #fff; padding: 4px 10px; border-radius: 3px; font-weight: 600;';
			}
		} else {
			$mark_style = 'background: transparent; color: #333; padding: 0; font-weight: normal;';
		}

		echo '<tr style="background: ' . $row_bg . ';">';
		echo '<td style="width: 40%; padding: 10px 12px; font-weight: 600; color: #555; font-size: 13px;">' . esc_html( $display_title ) . '</td>';
		echo '<td style="padding: 10px 12px; font-size: 13px;"><mark class="' . esc_attr( $class ) . '" style="' . $mark_style . '">' . esc_html( $value ) . '</mark></td>';
		echo '</tr>';
	}
} else {
	?>
    <tr>
        <td colspan="3" style="text-align: center; padding: 30px; background: #fff5f5;">
            <span class="dashicons dashicons-warning"
                  style="color: #dc3232; font-size: 48px; display: block; margin-bottom: 15px;"></span>
            <p style="color: #dc3232; font-size: 16px; margin-bottom: 20px; font-weight: 600;">License Validation
                Failed</p>
            <p style="color: #666; margin-bottom: 20px;">Please check your license key or contact support for
                assistance.</p>
            <a href="https://themeson.com/license" target="_blank" class="button button-primary button-large">Get Valid
                License Key</a>
        </td>
    </tr>
	<?php
}
?>