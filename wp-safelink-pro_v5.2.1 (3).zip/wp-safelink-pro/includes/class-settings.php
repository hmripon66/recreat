<?php
/**
 * WP Safelink Settings
 *
 * @author WP Safelink
 * @package WP Safelink
 * @since 1.0.0
 */
if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

if (!class_exists('WPSafelink_Settings')) :

    class WPSafelink_Settings
    {

        /**
         * Option name
         */
        private $opt_setting_key = 'wpsafelink_settings';

        /**
         * Constructor
         *
         * @return void
         * @since 1.0.0
         */
        public function __construct()
        {
            add_action('admin_enqueue_scripts', array($this, 'admin_enqueue'));
            add_action('admin_menu', array($this, 'add_menu_page'));
            add_action('admin_init', array($this, 'handle_wizard_redirects'));
            add_action('init', array($this, 'default_setting'));

	        add_action( 'init', array( $this, 'create_safelink_js' ) );

	        // Wizard AJAX handlers
	        add_action('wp_ajax_wpsafelink_validate_license', array($this, 'ajax_validate_license'));
	        add_action('wp_ajax_wpsafelink_change_license', array($this, 'ajax_change_license'));
	        add_action('wp_ajax_wpsafelink_check_integration', array($this, 'ajax_check_integration'));
	        add_action( 'wp_ajax_wpsafelink_license_status', array( $this, 'ajax_license_status' ) );

	        // REST API initialization
	        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
        }

        public function create_safelink_js() {
	        $current_url = $_SERVER['REQUEST_URI'];
	        if ( strpos( $current_url, 'wpsafelink.js' ) === false ) {
		        return;
	        }

	        $options = wpsafelink_options();

	        $method = $options['auto_convert_link_method'];

	        $dm = "";
	        $dm_exclude = "";
	        if ($method == "include") {
		        $dom = explode( PHP_EOL, $options['domain_list']);
		        $dom = array_map( 'trim', $dom );
		        $dom = array_map( 'strtolower', $dom );
		        $dm  = '';
		        $rep = array( 'https://', 'http://', 'www.' );
		        foreach ( $dom as $d ) {
			        $dm .= '"' . $d . '",';
		        }
	        } else {
		        $dom_exclude = explode(PHP_EOL, $options['domain_list']);
		        $dom_exclude = array_map('trim', $dom_exclude);
		        $dom_exclude = array_map('strtolower', $dom_exclude);
		        $dm_exclude = '';
		        $rep = array('https://', 'http://', 'www.');
		        foreach ($dom_exclude as $d) {
			        $dm_exclude .= '"' . $d . '",';
		        }
            }

	        $domain = (empty($options['auto_convert_link_base_url']) ? home_url() : $options['auto_convert_link_base_url']);
	        $domain = (substr($domain, -1) != '/' ? $domain . '/' : $domain);
	        if ($options['permalink'] == 1) {
		        $safe_link = $domain . $options['permalink_parameter'] . '/';
	        } else if ($options['permalink'] == 2) {
		        $safe_link = $domain . '?' . $options['permalink_parameter'] . '=';
	        } else {
		        $safe_link = home_url() . '?';
	        }

	        $replace = array(
		        '{base_url}' => $safe_link,
		        '{domain}' => rtrim($dm, ","),
		        '{exclude_domain}' => rtrim($dm_exclude, ",")
	        );

	        $js = file_get_contents(wpsafelink_plugin_path() . '/assets/wpsafelink.js');
	        $js = str_replace(array_keys($replace), array_values($replace), $js);

	        require_once wpsafelink_plugin_path() . '/vendor/HunterObfuscator.php';
	        $hunter = new HunterObfuscator($js);
	        $obsfucated = $hunter->Obfuscate();

	        header( 'Content-Type: application/javascript' );
	        echo $obsfucated;
	        die();
        }

        /**
         * Clear cached license script
         *
         * @access  private
         * @return  void
         * @since   1.0.0
         */
        private function clear_cached_license_script()
        {
	        // Clear the old file-based license storage (for backward compatibility)
            $cached = wpsafelink_plugin_path() . '/assets/wpsaf.script.js';
            if (file_exists($cached)) {
                unlink($cached);
            }

	        // Clear the new wp_options-based license storage
	        delete_option( 'wpsafelink_license_data' );
	        delete_option( 'wpsafelink_license_migrated' );
        }

        /**
         * Initialize default settings if options don't exist
         *
         * @access  private
         * @return  void
         * @since   1.0.0
         */
        private function initialize_default_settings()
        {
            $exist_options = wpsafelink_options();
            if (!$exist_options) {
                $all_settings = [
                    'general',
                    'auto-generate-link',
                    'templates',
	                'styles',
                    'captcha',
                    'advertisement',
                    'anti-adblock',
                    'adlinkfly'
                ];
                $default_options = [];
                foreach ($all_settings as $setting) {
                    $options = $this->get_general_options($setting);
                    $default_options = array_merge($default_options, $options);
                }

                $update_options = [];
                foreach ($default_options as $key => $value) {
                    $disabled = $value['disabled'] ?? false;
                    if ($disabled) {
                        continue;
                    }
                    $update_options[$key] = $value['default'] ?? "";
                }

                update_option($this->opt_setting_key, $update_options);
            }
        }

        /**
         * Change settings to default setting
         *
         * @access  public
         * @return  void
         * @since   1.0.0
         */
        /**
         * Handle wizard redirects
         *
         * @access  public
         * @return  void
         * @since   5.1.3
         */
        public function handle_wizard_redirects()
        {
            // Only handle redirects on our plugin page
            if (!isset($_GET['page']) || $_GET['page'] !== 'wpsafelink') {
                return;
            }

            // Check for activation redirect
            if (get_transient('wpsafelink_activation_redirect')) {
                delete_transient('wpsafelink_activation_redirect');
                wp_redirect(admin_url('admin.php?page=wpsafelink&wizard_step=license'));
                exit;
            }

            // Check if wizard should be shown (mandatory license redirect)
            $wizard_step = $_GET['wizard_step'] ?? null;
            if (!$wizard_step) {
                global $wpsafelink_core;
                $license = $wpsafelink_core->license();
                $check_license = $license['success'] ?? false;

	            if (!$check_license) {
                    wp_redirect(admin_url('admin.php?page=wpsafelink&wizard_step=license'));
                    exit;
                }
            }
        }

        public function default_setting($force = false)
        {
        }

        /**
         * Enqueue scripts and style
         *
         * @access  public
         * @return  void
         * @since   1.0.0
         */
	    public function admin_enqueue( $hook = '' )
        {
	        // Only enqueue on our plugin settings page
	        if ( $hook !== 'toplevel_page_wpsafelink' ) {
		        return;
	        }

	        // Media uploader for Styles tab (and media fields)
	        if ( function_exists( 'wp_enqueue_media' ) ) {
		        wp_enqueue_media();
	        }
	        $css_url = plugins_url( 'assets/css/admin.css', wpsafelink_plugin_file() );
	        $ver     = '';
	        if ( file_exists( wpsafelink_plugin_path() . '/assets/css/admin.css' ) ) {
		        $ver = filemtime( wpsafelink_plugin_path() . '/assets/css/admin.css' );
	        }
	        wp_enqueue_style( 'wpsafelink-admin', $css_url, array(), $ver );

	        // Enqueue consolidated wizard/settings stylesheet
	        if ( isset( $_GET['wizard_step'] ) ) {
		        $css_url = plugins_url( 'assets/css/wizard.css', wpsafelink_plugin_file() );
		        $ver     = '';
		        if ( file_exists( wpsafelink_plugin_path() . '/assets/css/wizard.css' ) ) {
			        $ver = filemtime( wpsafelink_plugin_path() . '/assets/css/wizard.css' );
		        }
		        wp_enqueue_style( 'wpsafelink-wizard', $css_url, array(), $ver );
	        }

	        // Localize script for AJAX
	        wp_localize_script( 'jquery', 'wpsafelink_ajax', array(
		        'ajax_url' => admin_url( 'admin-ajax.php' ),
		        '_wpnonce' => wp_create_nonce( 'wpsafelink_ajax_nonce' ),
	        ) );
        }

        /**
         * Adding Menu
         *
         * @access  public
         * @return  void
         * @since   1.0.0
         */
        public function add_menu_page()
        {
            add_menu_page(
                'WP Safelink',
                'WP Safelink',
                'manage_options',
                'wpsafelink',
                array($this, 'submenu_page_callback'),
                ''
            );
        }

        /**
         * Print the UI Settings
         *
         * @access  public
         * @return  void
         * @since   1.0.0
         */
        public function submenu_page_callback()
        {
            global $wpsafelink_core;
            $success_update = '';
            $success_message = '';
            $error_update = '';
            $error_message = '';

            // Check if wizard should be shown
            $wizard_step = $_GET['wizard_step'] ?? null;
            $license = $wpsafelink_core->license();
            $check_license = $license['success'] ?? false;
            $wizard_completed = get_option('wpsafelink_wizard_completed', false);

	        // If wizard step is requested, show wizard
            if ($wizard_step) {
                $this->display_wizard();
                return;
            }

            // Process save data
            if (isset($_POST['action'])) {
                if ($_POST['action'] == 'save') {
                    $post_options = $_POST['wpsafelink'] ?? array();

                    $current_options = wpsafelink_options();
                    $post_options = array_merge($current_options, $post_options);

                    update_option($this->opt_setting_key, $post_options);

                    $success_update = true;
                    $success_message = 'Settings saved.';
                } else if ($_POST['action'] == 'license') {
                    if (isset($_POST['sub']) && $_POST['sub'] == 'Change License') {
                        $this->clear_cached_license_script();
	                    $success_update  = true;
	                    $success_message = 'License cleared successfully. Please enter a new license.';
                    } else {
                        $license = $_POST['wpsafelink_license'];
                        $check_license = $wpsafelink_core->license($license);
	                    if ( $check_license['success'] ) {
                            $success_update = true;
                            $success_message = 'License validated.';

	                        $this->initialize_default_settings();
                        } else {
                            $error_update = true;
		                    $error_message = $check_license['data']->msg;
                        }
                    }
                } else if ($_POST['action'] == 'generate_link') {
                    $target_link = $_POST['wpsafelink_link'];
                    $link = $wpsafelink_core->postGenerateLink($target_link);
                    $success_update = true;
                    $success_message = 'Target Link : <code><a target="_blank" href="' . $target_link . '">' . $target_link . '</a></code><br/>Your Safelink : <code><a target="_blank" href="' . $link['generated3'] . '">' . $link['generated3'] . '</a></code> OR <code><a target="_blank" href="' . $link['encrypt_link'] . '">' . $link['encrypt_link'] . '</a></code>';
                }
            }
            if (isset($_GET['delete']) && $_GET['delete'] > 0) {
                global $wpdb;
                $wpdb->delete("{$wpdb->prefix}wpsafelink", array('ID' => $_GET['delete']), '');

                $success_update = true;
                $success_message = 'Safelink deleted.';
            }

            $tab = (!empty($_GET['tab']) ? $_GET['tab'] : 'generate-link');
	        // Backward compatibility: map old Styles tab to Templates
	        if ( $tab === 'styles' ) {
		        $tab = 'templates';
	        }
            $plugin_data = get_plugin_data(wpsafelink_plugin_file());
            $data = wpsafelink_options();

	        $license                       = $wpsafelink_core->license();
	        $check_license                 = $license['success'];
            ?>
            <div id="wpsafelink-settings" class="wrap">

                <?php if ($success_update) : ?>
                    <div id="setting-error-settings_updated" class="updated settings-error notice is-dismissible">
                        <p><strong><?php echo $success_message; ?></strong></p>
                        <button type="button" class="notice-dismiss"><span
                                    class="screen-reader-text">Dismiss this notice.</span></button>
                    </div>
                <?php endif; ?>

                <?php if ($error_update) : ?>
                    <div id="setting-error-settings_updated" class="notice notice-error is-dismissible">
                        <p><strong><?php echo $error_message; ?></strong></p>
                        <button type="button" class="notice-dismiss"><span
                                    class="screen-reader-text">Dismiss this notice.</span></button>
                    </div>
                <?php endif; ?>

                <h1><?php echo $plugin_data['Title']; ?>
                    <small><code>version <?php echo $plugin_data['Version']; ?></code></small></h1>
                <p><?php echo $plugin_data['Description']; ?></p>

	            <?php if ( $check_license ) : ?>
                    <style>
                        .wpsafelink_license_status_table .spinner {
                            visibility: visible;
                            float: none;
                            margin: 0;
                        }

                        .wpsafelink_license_status_table mark.yes {
                            background: #7ad03a;
                            color: #fff;
                            padding: 3px 8px;
                            border-radius: 3px;
                            font-weight: 600;
                        }

                        .wpsafelink_license_status_table mark.no {
                            background: #e74c3c;
                            color: #fff;
                            padding: 3px 8px;
                            border-radius: 3px;
                            font-weight: 600;
                        }

                        .wpsafelink_license_status_table tbody td {
                            padding: 10px 12px;
                        }

                        /* Responsive positioning for larger screens */
                        @media screen and (min-width: 1200px) {
                            #wpsafelink-license-status {
                                position: absolute;
                                right: 20px;
                                top: 20px;
                                width: 350px;
                                margin-top: 0 !important;
                                z-index: 100;
                                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.13);
                                background: #fff;
                                border-radius: 4px;
                                overflow: hidden;
                            }

                            #wpsafelink-settings {
                                position: relative;
                                padding-right: 380px;
                            }

                            .wpsafelink_license_status_table {
                                max-width: 100% !important;
                                border: none;
                            }
                        }

                        /* For smaller screens, keep default stacked layout */
                        @media screen and (max-width: 999px) {
                            #wpsafelink-license-status {
                                display: block;
                                margin-top: 20px;
                                position: static;
                            }

                            .wpsafelink_license_status_table {
                                max-width: 100%;
                            }
                        }
                    </style>
                    <div id="wpsafelink-license-status">
                        <table class="wpsafelink_license_status_table widefat" id="wpsafelink_license_status"
                               cellspacing="0">
                            <thead>
                            <tr>
                                <th colspan="3"
                                    style="font-size: 14px; padding: 12px; background: #23282d; color: #fff;">WP
                                    Safelink License Status
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td colspan="3" class="load_status" style="text-align: center; padding: 20px;">
                                    <span class="spinner is-active" style="float: none; margin: 0 auto;"></span>
                                    <span style="margin-left: 10px;">Checking license status with server...</span>
                                </td>
                            </tr>
                            </tbody>
                            <tfoot>
                            </tfoot>
                        </table>
                    </div>

                    <script type="text/javascript">
                        function wpsafelink_check_license_status() {
                            jQuery.ajax({
                                url: wpsafelink_ajax.ajax_url,
                                type: 'POST',
                                data: {
                                    action: 'wpsafelink_license_status',
                                    _wpnonce: wpsafelink_ajax._wpnonce,
                                    page: 'wpsafelink',
                                    tab: '<?php echo esc_js( $tab ); ?>'
                                },
                                success: function (response) {
                                    if (response.status === 'success') {
                                        jQuery('#wpsafelink_license_status tbody').html(response.message);
                                    } else {
                                        jQuery('#wpsafelink_license_status tbody').html('<tr><td colspan="3" style="text-align: center; padding: 20px; color: #dc3232;">Failed to check license status</td></tr>');
                                    }
                                },
                                error: function (response) {
                                    jQuery('#wpsafelink_license_status tbody').html('<tr><td colspan="3" style="text-align: center; padding: 20px; color: #dc3232;">Failed to connect to license server</td></tr>');
                                }
                            });
                        }

                        jQuery(document).ready(function ($) {
                            // Check license status on page load
                            if ($('#wpsafelink_license_status').length) {
                                wpsafelink_check_license_status();
                            }
                        });
                    </script>
	            <?php endif; ?>

                <?php if (!$check_license) :
                    require_once wpsafelink_plugin_path() . '/views/settings/settings-license.php';
                else: ?>
                    <h2 class="nav-tab-wrapper">
                        <a class="nav-tab generate-link <?php echo( $tab == 'generate-link' ? 'nav-tab-active' : '' ); ?>"
                           href="admin.php?page=wpsafelink&tab=generate-link">Generate Link</a>
                        <a class="nav-tab general <?php echo( $tab == 'general' ? 'nav-tab-active' : '' ); ?>"
                           href="admin.php?page=wpsafelink&tab=general">General</a>
                        <a class="nav-tab templates <?php echo( $tab == 'templates' ? 'nav-tab-active' : '' ); ?>"
                           href="admin.php?page=wpsafelink&tab=templates">Templates</a>

                        <?php do_action('wpsafelink_tab', $tab); ?>

                        <a class="nav-tab integration <?php echo( $tab == 'integration' ? 'nav-tab-active' : '' ); ?>"
                           href="admin.php?page=wpsafelink&tab=integration">Integration</a>
                        <a class="nav-tab license <?php echo( $tab == 'license' ? 'nav-tab-active' : '' ); ?>"
                           href="admin.php?page=wpsafelink&tab=license">License</a>
                    </h2>


                    <div class="wpsafelink-settings">
                        <?php
                        if ($tab === 'general') :
	                        // Merge General + Auto Generate Link + Captcha + Advertisement + Anti Adblock
	                        $options = [];
	                        // General section
	                        $options = array_merge( $options, [
		                        'title_general_section' => [
			                        'title'       => 'General Settings',
			                        'type'        => 'title',
			                        'description' => ''
		                        ]
	                        ] );
	                        $options = array_merge( $options, $this->get_general_options( 'general' ) );
	                        // Auto Generate Link section
	                        $options = array_merge( $options, [
		                        'title_autogen_section' => [
			                        'title'       => 'Auto Generate Link',
			                        'type'        => 'title',
			                        'description' => ''
		                        ]
	                        ] );
	                        $options = array_merge( $options, $this->get_general_options( 'auto-generate-link' ) );
	                        // Captcha section
	                        $options = array_merge( $options, [
		                        'title_captcha_section' => [
			                        'title'       => 'Captcha Settings',
			                        'type'        => 'title',
			                        'description' => ''
		                        ]
	                        ] );
	                        $options = array_merge( $options, $this->get_general_options( 'captcha' ) );
	                        // Advertisement section
	                        $options = array_merge( $options, [
		                        'title_advertisement_section' => [
			                        'title'       => 'Advertisement Settings',
			                        'type'        => 'title',
			                        'description' => ''
		                        ]
	                        ] );
	                        $options = array_merge( $options, $this->get_general_options( 'advertisement' ) );
	                        // Anti Adblock section
	                        $options = array_merge( $options, [
		                        'title_anti_adblock_section' => [
			                        'title'       => 'Anti Adblock Settings',
			                        'type'        => 'title',
			                        'description' => ''
		                        ]
	                        ] );
	                        $options = array_merge( $options, $this->get_general_options( 'anti-adblock' ) );
                            require_once wpsafelink_plugin_path() . '/views/settings/settings-general.php';
                        elseif ($tab === 'templates') :
	                        // Combine Templates and Styles into a single Templates tab
	                        $options = [];
	                        $options = array_merge( $options, $this->get_general_options( 'templates' ) );
	                        $options = array_merge( $options, $this->get_general_options( 'styles' ) );
	                        require_once wpsafelink_plugin_path() . '/views/settings/settings-general.php';
                        elseif ($tab === 'license') :
                            require_once wpsafelink_plugin_path() . '/views/settings/settings-license.php';
                        elseif ($tab === 'generate-link') :
	                        require_once wpsafelink_plugin_path() . '/views/settings/settings-generate-link.php';
                        elseif ( $tab === 'integration' ) :
	                        $options = $this->get_general_options( 'integration' );
	                        require_once wpsafelink_plugin_path() . '/views/settings/settings-integration.php';
                            ?>
                        <?php endif; ?>

                        <?php do_action('wpsafelink_tab_content', $tab); ?>
                    </div>
                <?php endif; ?>
            </div>


	        <?php
        }

        /**
         * Get general options
         *
         * @access  public
         * @return  array   Options list
         * @since   1.0.0
         */
        function get_general_options($type = 'general')
        {
	        $options = [];
            if ($type == 'general') {
                $options = array(
                    'auto_save_safelink' => array(
                        'id' => 'auto_save_safelink',
                        'title' => 'Auto Save Safelink',
                        'type' => 'checkbox',
                        'label' => 'Activate Auto Save Safelink',
                        'default' => 'no'
                    ),
                    'redirect_safelink' => array(
                        'id' => 'redirect_safelink',
                        'title' => 'Redirect Safelink',
                        'type' => 'checkbox',
                        'label' => 'Activate Redirect Safelink',
                        'default' => 'yes'
                    ),
                    'permalink' => array(
                        'id' => 'permalink',
                        'title' => 'Permalink Type',
                        'type' => 'select',
                        'label' => 'Permalink Type',
                        'options' => [
                            '1' => get_bloginfo('url') . '/[PARAMETER]/safelink_code',
                            '2' => get_bloginfo('url') . '/?[PARAMETER]=safelink_code',
                            '3' => get_bloginfo('url') . '/?safelink_code',
                        ],
                        'default' => '1'
                    ),
                    'permalink_parameter' => array(
                        'id' => 'permalink_parameter',
                        'title' => 'Permalink Parameter',
                        'type' => 'text',
                        'label' => 'Permalink Parameter',
                        'default' => 'go'
                    ),
                    'content_method' => [
                        'id' => 'content_method',
                        'title' => 'Content Method',
                        'type' => 'select',
                        'label' => 'Content Method',
                        'options' => [
                            'random' => 'Random All Posts',
                            'selected' => 'Selected Posts',
                        ],
                        'default' => 'random'
                    ],
                    'content_ids' => [
                        'id' => 'content_ids',
                        'title' => 'Content IDs',
                        'type' => 'textarea',
                        'label' => 'Content IDs',
                        'description' => 'Enter the post IDs, separated by new line',
                    ]
                );
            } else if ($type == 'auto-generate-link') {
                $options = array(
                    'auto_convert_link' => array(
                        'id' => 'auto_convert_link',
                        'title' => 'Auto Convert Link',
                        'type' => 'checkbox',
                        'label' => 'Auto Convert Link',
                        'default' => 'no'
                    ),
                    'auto_convert_link_base_url' => array(
                        'id' => 'auto_convert_link_base_url',
                        'title' => 'Base URL',
                        'type' => 'text',
                        'default' => get_bloginfo('url'),
                        'readonly' => true
                    ),
                    'auto_convert_link_method' => [
                        'title' => 'Auto Convert Link Method',
                        'id' => 'auto_convert_link_method',
                        'type' => 'select',
                        'options' => [
                            'include' => 'Include Domain',
                            'exclude' => 'Exclude Domain',
                        ],
                        'description' => 'Select the method for auto convert link',
                        'default' => 'include'
                    ],
                    'domain_list' => [
                        'title' => 'Domain List',
                        'id' => 'domain_list',
                        'type' => 'textarea',
                        'description' => 'Enter the domain list, separated by new line',
                    ],
                    'title_auto_generate_link_script' => [
                        'title' => 'How to use',
                        'type' => 'title',
                        'description' => '<p>Place this code before the <b>&lt;/body&gt;</b> tag</p><p style="color:red;"><code>&lt;script src="' . get_bloginfo('url') . '/wpsafelink.js"&gt;&lt;/script&gt;</code></p>'
                    ]
                );
            } else if ($type == 'templates') {
                $templates = [];
                $temps = glob(wpsafelink_plugin_path() . '/template/*.php');
	            $default_template = '';
                foreach ($temps as $t) {
                    $t = explode('/', $t);
                    $t = $t[count($t) - 1];
                    $t = str_replace('.php', '', $t);
                    $templates[$t] = $t;
	                if ( empty( $default_template ) ) {
		                $default_template = $t;
	                }
                }

                $options = array(
	                'title_templates_settings' => [
		                'title'       => 'Template Settings',
		                'type'        => 'title',
		                'description' => 'Choose the safelink template and adjust its behavior.'
	                ],
                    'template' => array(
                        'title' => 'Template',
                        'id' => 'template',
                        'type' => 'select',
                        'options' => $templates,
                        'default' => $default_template
                    ),
	                'title_template_behavior'  => [
		                'title'       => 'Behavior',
		                'type'        => 'title',
		                'description' => ''
	                ],
                    'verification_homepage' => array(
	                    'id'    => 'verification_homepage',
	                    'title' => 'Verification on Homepage',
	                    'type'  => 'checkbox',
	                    'label' => 'Verification on Homepage',
                    ),
                    'skip_verification' => array(
	                    'id'    => 'skip_verification',
	                    'title' => 'Skip Verification',
	                    'type'  => 'checkbox',
	                    'label' => 'Skip Verification',
                    ),
                    'time_delay' => [
                        'id' => 'time_delay',
                        'title' => 'Time Delay',
                        'type' => 'text',
                        'description' => 'Time delay in seconds',
                        'default' => '5'
                    ],
                    'time_delay_message' => [
                        'id' => 'time_delay_message',
                        'title' => 'Time Delay Message',
                        'type' => 'textarea',
                        'description' => '*Use syntax <code>{time}</code> HTML Support',
                        'default' => 'Thank you for your visit. Your links will be created in {time} seconds.'
                    ],

                );
            } else if ( $type == 'styles' ) {
	            $options = array(
		            'title_styles_appearance'  => [
			            'title'       => 'Appearance',
			            'type'        => 'title',
			            'description' => 'Customize the look and feel of WP Safelink components.'
		            ],
		            'style_logo'               => [
			            'id'          => 'style_logo',
			            'title'       => 'Logo',
			            'type'        => 'media',
			            'description' => 'Upload a logo used by templates and components.',
			            'default'     => wpsafelink_plugin_url() . '/assets/logo.png'
		            ],
		            'style_font_family'        => [
			            'id'      => 'style_font_family',
			            'title'   => 'Font Family',
			            'type'    => 'select',
			            'options' => [
				            'system-ui' => 'System UI (Default)',
				            'inter'     => 'Inter (System fallback)',
				            'arial'     => 'Arial',
				            'roboto'    => 'Roboto',
				            'georgia'   => 'Georgia',
			            ],
			            'default' => 'system-ui'
		            ],
		            'style_font_size'          => [
			            'id'          => 'style_font_size',
			            'title'       => 'Base Font Size',
			            'type'        => 'text',
			            'description' => 'CSS size value (e.g. 16px)',
			            'default'     => '16px'
		            ],
		            'style_text_color'         => [
			            'id'      => 'style_text_color',
			            'title'   => 'Text Color',
			            'type'    => 'color',
			            'default' => '#111827'
		            ],
		            'style_muted_color'        => [
			            'id'      => 'style_muted_color',
			            'title'   => 'Muted Text Color',
			            'type'    => 'color',
			            'default' => '#6b7280'
		            ],
		            'style_border_color'       => [
			            'id'      => 'style_border_color',
			            'title'   => 'Border Color',
			            'type'    => 'color',
			            'default' => '#e5e7eb'
		            ],
		            'style_background_color'   => [
			            'id'      => 'style_background_color',
			            'title'   => 'Background Color',
			            'type'    => 'color',
			            'default' => '#ffffff'
		            ],
		            'style_accent_color'       => [
			            'id'      => 'style_accent_color',
			            'title'   => 'Primary (Accent) Color',
			            'type'    => 'color',
			            'default' => '#2563eb'
		            ],
		            'style_accent_hover_color' => [
			            'id'      => 'style_accent_hover_color',
			            'title'   => 'Primary Hover Color',
			            'type'    => 'color',
			            'default' => '#1d4ed8'
		            ],
		            'style_radius' => [
			            'id'          => 'style_radius',
			            'title'       => 'Border Radius',
			            'type'        => 'text',
			            'description' => 'CSS size value (e.g. 8px)',
			            'default'     => '10px'
		            ],

		            'generate_manual_scroll' => [
			            'id'      => 'generate_manual_scroll',
			            'title'   => 'Manual Scroll to Get Link',
			            'type'    => 'checkbox',
			            'label'   => 'Require users to manually scroll to the link section',
			            'default' => 'no'
		            ],

		            'title_styles_action'   => [
			            'title'       => 'Action Button',
			            'type'        => 'title',
			            'description' => 'Configure styles for action buttons (or image-based buttons).'
                    ],
                    'action_button' => [
                        'id' => 'action_button',
                        'title' => 'Action Button Type',
                        'type' => 'select',
                        'options' => [
                            'button' => 'Button',
                            'image' => 'Image'
                        ]
                    ],
                    'action_button_image_1' => [
                        'id' => 'action_button_image_1',
                        'title' => 'Image Button (Human Verification)',
                        'type' => 'media',
                        'default' => wpsafelink_plugin_url() . '/assets/human-verification4.png'
                    ],
                    'action_button_image_2' => [
                        'id' => 'action_button_image_2',
                        'title' => 'Image Button 1 (Generate Link)',
                        'type' => 'media',
                        'default' => wpsafelink_plugin_url() . '/assets/generate4.png'
                    ],
                    'action_button_image_3' => [
                        'id' => 'action_button_image_3',
                        'title' => 'Image Button 2 (Please Wait)',
                        'type' => 'media',
                        'default' => wpsafelink_plugin_url() . '/assets/wait4.png'
                    ],
                    'action_button_image_4' => [
                        'id' => 'action_button_image_4',
                        'title' => 'Image Button 3 (Target Link)',
                        'type' => 'media',
                        'default' => wpsafelink_plugin_url() . '/assets/target4.png'
                    ],
                    'action_button_text_1' => [
                        'id' => 'action_button_text_1',
                        'title' => 'Button Text (Human Verification)',
                        'type' => 'text',
                        'default' => 'IM NOT ROBOT'
                    ],
                    'action_button_text_2' => [
                        'id' => 'action_button_text_2',
                        'title' => 'Button Text 1 (Generate Link)',
                        'type' => 'text',
                        'default' => 'CLICK 2X FOR GENERATE LINK'
                    ],
                    'action_button_text_3' => [
                        'id' => 'action_button_text_3',
                        'title' => 'Button Text 2 (Please Wait)',
                        'type' => 'text',
                        'default' => 'PLEASE WAIT ...'
                    ],
                    'action_button_text_4' => [
                        'id' => 'action_button_text_4',
                        'title' => 'Button Text 3 (Target Link)',
                        'type' => 'text',
                        'default' => 'DOWNLOAD LINK'
                    ],
                );
            } else if ($type == 'captcha') {
                $options = array(
                    'captcha_enable' => [
                        'id' => 'captcha_enable',
                        'title' => 'Enable/Disable Captcha',
                        'type' => 'checkbox',
                        'label' => 'Enable Captcha',
                    ],
                    'captcha' => array(
                        'title' => 'Captcha Provider',
                        'id' => 'captcha',
                        'type' => 'select',
                        'label' => 'Select Captcha',
                        'options' => array(
                            'recaptcha' => 'reCAPTCHA',
                            'hcaptcha' => 'hCaptcha',
                        ),
                    ),
                    'recaptcha_title' => [
                        'title' => 'reCAPTCHA',
                        'type' => 'title',
                        'description' => 'Get your site key and secret key from <a href="https://www.google.com/recaptcha" target="_blank">Google reCAPTCHA</a>'
                    ],
                    'recaptcha_site_key' => array(
                        'id' => 'recaptcha_site_key',
                        'title' => 'Site Key',
                        'type' => 'text',
                        'label' => 'Site Key',
                    ),
                    'recaptcha_secret_key' => array(
                        'id' => 'recaptcha_secret_key',
                        'title' => 'Secret Key',
                        'type' => 'text',
                        'label' => 'Secret Key'
                    ),
                    'recaptcha_label' => array(
                        'id' => 'recaptcha_label',
                        'title' => 'reCAPTCHA Alert Verification Text',
                        'type' => 'text',
                        'label' => 'Label',
                        'default' => 'Please complete reCAPTCHA verification'
                    ),
                    'hcaptcha_title' => [
                        'title' => 'hCaptcha',
                        'type' => 'title',
                        'description' => 'Get your site key and secret key from <a href="https://www.hcaptcha.com" target="_blank">hCaptcha</a>'
                    ],
                    'hcaptcha_site_key' => array(
                        'id' => 'hcaptcha_site_key',
                        'title' => 'Site Key',
                        'type' => 'text',
                        'label' => 'Site Key',
                    ),
                    'hcaptcha_secret_key' => array(
                        'id' => 'hcaptcha_secret_key',
                        'title' => 'Secret Key',
                        'type' => 'text',
                        'label' => 'Secret Key'
                    ),
                    'hcaptcha_label' => array(
                        'id' => 'hcaptcha_label',
                        'title' => 'hCaptcha Alert Verification Text',
                        'type' => 'text',
                        'label' => 'Label',
                        'default' => 'Please complete hCaptcha verification'
                    ),
                );
            } else if ($type == 'advertisement') {
                $options = array(
                    'advertisement_top_1' => array(
                        'title' => 'Advertisement Top (Before Button)',
                        'id' => 'advertisement_top_1',
                        'type'    => 'textarea',
                        'default' => '<a href="https://themeson.com" target="_blank"><img src="https://placehold.co/300x250" /></a>'
                    ),
                    'advertisement_top_2' => array(
                        'title' => 'Advertisement Top (After Button)',
                        'id' => 'advertisement_top_2',
                        'type'    => 'textarea',
                        'default' => '<a href="https://themeson.com" target="_blank"><img src="https://placehold.co/300x250" /></a>'
                    ),
                    'advertisement_bottom_full_screen' => array(
	                    'title'   => 'Advertisement Bottom Full Screen',
	                    'id'      => 'advertisement_bottom_full_screen',
	                    'type'    => 'checkbox',
	                    'label'   => 'Enable Advertisement Bottom Full Screen',
	                    'default' => 'yes'
                    ),
                    'advertisement_bottom_1' => array(
                        'title' => 'Advertisement Bottom (Before Button)',
                        'id' => 'advertisement_bottom_1',
                        'type'    => 'textarea',
                        'default' => '<a href="https://themeson.com" target="_blank"><img src="https://placehold.co/300x600" /></a>'
                    ),
                    'advertisement_bottom_2' => array(
                        'title' => 'Advertisement Bottom (After Button)',
                        'id' => 'advertisement_bottom_2',
                        'type'    => 'textarea',
                        'default' => '<a href="https://themeson.com" target="_blank"><img src="https://placehold.co/300x600" /></a>'
                    ),
                );
            } else if ($type == 'anti-adblock') {
                $options = array(
                    'anti_adblock' => array(
                        'title' => 'Anti Adblock',
                        'id' => 'anti_adblock',
                        'type' => 'checkbox',
                        'label' => 'Enable Anti Adblock',
                    ),
                    'anti_adblock_header_1' => [
	                    'id' => 'anti_adblock_header_1',
                        'title' => 'Header text 1',
                        'type' => 'textarea',
                        'default' => 'Adblock Detected'
                    ],
                    'anti_adblock_header_2' => [
	                    'id' => 'anti_adblock_header_2',
                        'title' => 'Header text 2',
                        'type' => 'textarea',
                        'default' => 'Please turn off your adblocker to download'
                    ],
                );
            } else if ($type == 'adlinkfly') {
	            $options = array(
		            'title_adlinkfly'      => [
			            'title'       => 'Adlinkfly',
			            'type'        => 'title',
			            'description' => 'For demo purpose you can check this link <a href="https://demo-adlinkfly.themeson.com" target="_blank">https://demo-adlinkfly.themeson.com</a>'
		            ],
		            'adlinkfly'            => array(
			            'title' => 'Adlinkfly',
			            'id'    => 'adlinkfly',
			            'type'  => 'checkbox',
			            'label' => 'Enable Adlinkfly',
		            ),
		            'adlinkfly_url'        => [
			            'id'          => 'adlinkfly_url',
			            'title'       => 'Adlinkfly URL',
			            'type'        => 'text',
			            'description' => 'example : https://redir.themeson.com',
		            ],
		            'adlinkfly_secret_key' => [
			            'id'          => 'adlinkfly_secret_key',
			            'title'       => 'Adlinkfly Secret Key',
			            'type'        => 'text',
			            'default'     => md5( get_bloginfo( 'url' ) ),
			            'readonly'    => true,
			            'description' => 'Adlinkfly Secret Key is only for <strong><a href="https://themeson.com/safelink/" target="_blank">PRO VERSION</a></strong>. Its easy for integration and more secure for your safelink and tutorial will be available on <strong><a href="https://themeson.com/safelink/" target="_blank">PRO VERSION</a></strong> Configuration.'
		            ]
	            );
            } else if ( $type == 'setup' ) {
	            $valid_header_integration = $this->check_theme_integration( 'header' );
	            $valid_footer_integration = $this->check_theme_integration( 'footer' );
	            $options = array(
		            'title_installation' => [
			            'title'       => 'Installation',
			            'type'        => 'title',
			            'description' => 'Follow these steps to properly integrate WP Safelink into your WordPress theme. For detailed video tutorials and documentation, visit our <a href="https://kb.themeson.com/knowledge-base/integrate-wp-safelink-to-custom-theme" target="_blank">knowledge base</a>. If you need help, please visit <a href="https://support.themeson.com" target="_blank">https://support.themeson.com</a>.'
		            ],
		            'header_code'        => [
			            'id'          => 'header_code',
			            'title'       => 'Header Code',
			            'type'        => 'textarea',
			            'description' => 'Step 1: Open your theme\'s header.php file and paste this code just before the closing &lt;/head&gt; tag. This adds required scripts and styles.<br/><strong style="color:' . ( $valid_header_integration ? 'green' : 'red' ) . '">' . ( $valid_header_integration ? 'Header code integration verified!' : 'Header code integration required - follow Step 1' ) . '</strong>',
			            'default'     => "&lt;?php if(function_exists('newwpsafelink_top')) newwpsafelink_top();?&gt;",
			            'disabled'    => true
		            ],
		            'footer_code'        => [
			            'id'          => 'footer_code',
			            'title'       => 'Footer Code',
			            'type'        => 'textarea',
			            'description' => 'Step 2: Open your theme\'s footer.php file and paste this code just before the closing &lt;/body&gt; tag. This enables core safelink functionality.<br/><strong style="color:' . ( $valid_footer_integration ? 'green' : 'red' ) . '">' . ( $valid_footer_integration ? 'Footer code integration verified!' : 'Footer code integration required - follow Step 2' ) . '</strong>',
			            'default'     => "&lt;?php if(function_exists('newwpsafelink_bottom')) newwpsafelink_bottom();?&gt;",
			            'disabled'    => true
		            ],
		            'auto_link'          => [
			            'id'          => 'auto_link',
			            'title'       => 'Auto Generate Link Javascript',
			            'type'        => 'textarea',
			            'description' => 'Optional Step 3: To enable automatic link conversion on any webpage, add this JavaScript code before the closing &lt;/body&gt; tag. This allows WP Safelink to automatically convert links matching your settings.',
			            'default'     => "&lt;script src='" . get_bloginfo( 'url' ) . "/wpsafelink.js'&gt;&lt;/script&gt;",
			            'disabled'    => true
		            ]
	            );
            } else if ( $type == 'integration' ) {
	            // Generate API key dynamically
	            $api_key      = $this->generate_api_key();
	            $api_endpoint = get_rest_url( null, 'v1/wpsafelink/validate' );

	            $options = array(
		            'title_integration'  => [
			            'title'       => 'WP Safelink Integration',
			            'type'        => 'title',
			            'description' => 'Integrate WP Safelink with other extension plugins. This allows seamless connection between your main WP Safelink installation and other WordPress sites.'
		            ],
		            'api_key'            => [
			            'id'          => 'api_key',
			            'title'       => 'Integration Key',
			            'type'        => 'text',
			            'readonly'    => true,
			            'description' => 'This Integration key is generated dynamically based on your license. Use this key to authenticate with other WP Safelink plugins.<br><button type="button" class="button button-small" onclick="navigator.clipboard.writeText(\'' . esc_attr( $api_key ) . '\'); alert(\'API Key copied to clipboard!\');">Copy API Key</button>',
			            'default'     => $api_key
		            ],
		            'title_auto_convert' => [
			            'title'       => 'WP Safelink Auto Convert Link',
			            'type'        => 'title',
			            'description' => '<strong>WP Safelink Auto Convert Link</strong> automatically converts external links on your WordPress site to safelinks. Perfect for monetizing outbound links without manual intervention.<br><br><strong>Features:</strong><ul style="list-style: disc; margin-left: 20px;"><li>Automatic link conversion based on domain rules</li><li>Include/Exclude domain lists</li><li>Custom link patterns</li><li>Real-time conversion</li></ul>'
		            ],
		            'title_adlinkfly'    => [
			            'title'       => 'Adlinkfly Integration',
			            'type'        => 'title',
			            'description' => '<strong>Connect WP Safelink with Adlinkfly</strong> for enhanced monetization and link management.'
		            ],
		            // Moved from dedicated Adlinkfly tab into Integration
		            'adlinkfly'          => array(
			            'title' => 'Enable Adlinkfly',
			            'id'    => 'adlinkfly',
			            'type'  => 'checkbox',
			            'label' => 'Enable Adlinkfly',
		            ),
		            'adlinkfly_url'      => [
			            'id'          => 'adlinkfly_url',
			            'title'       => 'Adlinkfly URL',
			            'type'        => 'text',
			            'description' => 'Example: https://redir.themeson.com',
		            ],
		            'adlinkfly_secret_key' => [
			            'id'          => 'adlinkfly_secret_key',
			            'title'       => 'Adlinkfly Secret Key',
			            'type'        => 'text',
			            'default'     => md5( get_bloginfo( 'url' ) ),
			            'readonly'    => true,
			            'description' => 'Adlinkfly Secret Key is available in PRO version for easier and more secure integration.'
		            ]
	            );
            }

	        $options = apply_filters( 'wpsafelink_general_options', $options, $type );

            return $options;
        }

	    function check_theme_integration( $type ) {
		    if ( $type == 'header' ) {
			    $theme       = wp_get_theme();
			    $theme_root  = get_theme_root();
			    $header_file = $theme_root . '/' . $theme->get_stylesheet() . '/header.php';

			    if ( file_exists( $header_file ) ) {
				    $header_content = file_get_contents( $header_file );

				    return ( strpos( $header_content, 'newwpsafelink_top' ) !== false );
			    }

			    return false;
		    } else if ( $type == 'footer' ) {
			    $theme       = wp_get_theme();
			    $theme_root  = get_theme_root();
			    $footer_file = $theme_root . '/' . $theme->get_stylesheet() . '/footer.php';
			    if ( file_exists( $footer_file ) ) {
				    $footer_content = file_get_contents( $footer_file );

				    return ( strpos( $footer_content, 'newwpsafelink_bottom' ) !== false );
			    }

			    return false;
		    }

		    return false;
	    }

        /**
         * Display the setup wizard
         *
         * @access  public
         * @return  void
         * @since   5.1.3
         */
        public function display_wizard()
        {
            // Make settings instance available to wizard files
            $wpsafelink_settings_instance = $this;
            require_once wpsafelink_plugin_path() . '/views/settings/settings-wizard.php';
        }

        /**
         * AJAX handler for license validation
         *
         * @access  public
         * @return  void
         * @since   5.1.3
         */
        public function ajax_validate_license()
        {
            // Verify nonce
            if (!wp_verify_nonce($_POST['nonce'], 'wpsafelink_license_activation')) {
                wp_send_json_error(array('message' => 'Security check failed.'));
            }

            global $wpsafelink_core;

	        $license_key = sanitize_text_field($_POST['license_key']);
            $domain = sanitize_text_field($_POST['domain']);

	        if (empty($license_key)) {
                wp_send_json_error(array('message' => 'License key is required.'));
            }

	        // Validate license using existing core method
            $check_license = $wpsafelink_core->license($license_key);

	        if ($check_license['success']) {
                // Initialize default settings if first time
                $this->initialize_default_settings();

		        wp_send_json_success(array('message' => 'License activated successfully!'));
            } else {
                $error_message = $check_license['data']->msg ?? 'License validation failed.';
                wp_send_json_error(array('message' => $error_message));
            }
        }

        /**
         * AJAX handler for license change
         *
         * @access  public
         * @return  void
         * @since   5.1.3
         */
        public function ajax_change_license()
        {
            // Verify nonce
            if (!wp_verify_nonce($_POST['nonce'], 'wpsafelink_change_license')) {
                wp_send_json_error(array('message' => 'Security check failed.'));
            }

	        $this->clear_cached_license_script();

	        wp_send_json_success(array('message' => 'License cleared successfully.'));
        }

        /**
         * AJAX handler for integration checking
         *
         * @access  public
         * @return  void
         * @since   5.1.3
         */
        public function ajax_check_integration()
        {
            // Verify nonce
            if (!wp_verify_nonce($_POST['nonce'], 'wpsafelink_check_integration')) {
                wp_send_json_error(array('message' => 'Security check failed.'));
            }

	        $header_integration = $this->check_theme_integration('header');
            $footer_integration = $this->check_theme_integration('footer');

	        wp_send_json_success(array(
                'header' => $header_integration,
                'footer' => $footer_integration,
                'completed' => $header_integration && $footer_integration
            ));
        }

	    /**
	     * AJAX handler for license status checking
	     *
	     * @access  public
	     * @return  void
	     * @since   5.2.2
	     */
	    public function ajax_license_status() {
		    check_ajax_referer( 'wpsafelink_ajax_nonce', '_wpnonce' );

		    $output = array(
			    'status'  => 'error',
			    'message' => 'Invalid request'
		    );

		    global $wpsafelink_core;

		    // Measure response time
		    $start_time = microtime( true );

		    // Force check from API (bypass cache)
		    $license_response = $wpsafelink_core->license( '', false, true );

		    // Calculate response time
		    $end_time      = microtime( true );
		    $response_time = round( ( $end_time - $start_time ) * 1000 ); // Convert to milliseconds

		    if ( $license_response['success'] ) {
			    $data = $license_response['data'];

			    // Determine response time status
			    $response_class = 'yes';
			    if ( $response_time > 1000 ) {
				    $response_class = 'no';
			    }

			    // Format the response data - handle both object and array formats
			    $msg_data       = is_array( $data->msg ) ? $data->msg : (array) $data->msg;
			    $formatted_data = array(
				    'message' => 'License is Active and Valid',
				    'success' => true,
				    'result'  => array(
					    'license_key'   => substr( $msg_data['license'], 0, 10 ) . '*********',
					    'product'       => $msg_data['title'] ?? 'WP Safelink WordPress Plugin',
					    'status'        => $msg_data['status'] ?? 'active',
					    'domain'        => $msg_data['domain'] ?? str_replace( [
							    'https://',
							    'http://'
						    ], '', home_url() ),
					    'response_time' => $response_time . 'ms',
					    'last_check'    => date( 'd M Y, H:i:s' ),
				    )
			    );

			    ob_start();
			    require_once wpsafelink_plugin_path() . '/views/settings/license-product-status.php';
			    $output['message'] = ob_get_clean();
			    $output['status']  = 'success';
		    } else {
			    // License is not valid
			    $formatted_data = array(
				    'message' => 'License is Invalid or Expired',
				    'success' => false,
				    'result'  => array()
			    );

			    ob_start();
			    require_once wpsafelink_plugin_path() . '/views/settings/license-product-status.php';
			    $output['message'] = ob_get_clean();
			    $output['status']  = 'error';
		    }

		    wp_send_json( $output );
		    wp_die();
	    }

	    /**
	     * Register REST API routes
	     *
	     * @access  public
	     * @return  void
	     * @since   5.1.5
	     */
	    public function register_rest_routes() {
		    register_rest_route( 'v1/wpsafelink', '/validate', array(
			    'methods'             => 'POST',
			    'callback'            => array( $this, 'handle_api_validation' ),
			    'permission_callback' => '__return_true',
			    'args'                => array(
				    'key' => array(
					    'required'          => true,
					    'type'              => 'string',
					    'sanitize_callback' => 'sanitize_text_field'
				    )
			    )
		    ) );
	    }

	    /**
	     * Handle API validation endpoint
	     *
	     * @access  public
	     *
	     * @param WP_REST_Request $request
	     *
	     * @return  WP_REST_Response
	     * @since   5.1.5
	     */
	    public function handle_api_validation( $request ) {
		    $api_key = $request->get_param( 'key' );

		    if ( empty( $api_key ) ) {
			    return new WP_REST_Response( array( 'success' => false ), 200 );
		    }

		    $is_valid = $this->validate_api_key( $api_key );

		    return new WP_REST_Response( array( 'success' => $is_valid ), 200 );
	    }

	    /**
	     * Get first 3 digits from license
	     *
	     * @access  private
	     * @return  string
	     * @since   5.1.5
	     */
	    private function get_license_first_3_digits() {
		    global $wpsafelink_core;

		    // Get the full license key
		    $license_data = $wpsafelink_core->license( '', true );

		    if ( ! $license_data || strlen( $license_data ) < 3 ) {
			    // Fallback to a default if no license
			    return '000';
		    }

		    // Extract first 3 alphanumeric characters
		    $clean_license = preg_replace( '/[^a-zA-Z0-9]/', '', $license_data );

		    return substr( $clean_license, 0, 3 );
	    }

	    /**
	     * Simple encryption function
	     *
	     * @access  private
	     *
	     * @param string $string String to encrypt
	     * @param string $key Encryption key (3 digits)
	     *
	     * @return  string
	     * @since   5.1.5
	     */
	    private function encrypt_string( $string, $key ) {
		    // Simple XOR-based encryption with base64 encoding
		    $result     = '';
		    $key_length = strlen( $key );

		    for ( $i = 0; $i < strlen( $string ); $i ++ ) {
			    $char     = $string[ $i ];
			    $key_char = $key[ $i % $key_length ];
			    $result   .= chr( ord( $char ) ^ ord( $key_char ) );
		    }

		    return base64_encode( $result );
	    }

	    /**
	     * Simple decryption function
	     *
	     * @access  private
	     *
	     * @param string $encrypted Encrypted string
	     * @param string $key Decryption key (3 digits)
	     *
	     * @return  string|false
	     * @since   5.1.5
	     */
	    private function decrypt_string( $encrypted, $key ) {
		    $decoded = base64_decode( $encrypted );

		    if ( $decoded === false ) {
			    return false;
		    }

		    // XOR decryption (same as encryption for XOR cipher)
		    $result     = '';
		    $key_length = strlen( $key );

		    for ( $i = 0; $i < strlen( $decoded ); $i ++ ) {
			    $char     = $decoded[ $i ];
			    $key_char = $key[ $i % $key_length ];
			    $result   .= chr( ord( $char ) ^ ord( $key_char ) );
		    }

		    return $result;
	    }

	    /**
	     * Generate API key
	     *
	     * @access  public
	     * @return  string
	     * @since   5.1.5
	     */
	    public function generate_api_key() {
		    $prefix    = $this->get_license_first_3_digits();
		    $encrypted = $this->encrypt_string( home_url(), $prefix );

		    return $prefix . '-' . $encrypted;
	    }

	    /**
	     * Validate API key
	     *
	     * @access  public
	     *
	     * @param string $api_key
	     *
	     * @return  bool
	     * @since   5.1.5
	     */
	    public function validate_api_key( $api_key ) {
		    if ( strpos( $api_key, '-' ) === false ) {
			    return false;
		    }

		    list( $prefix, $encrypted ) = explode( '-', $api_key, 2 );

		    if ( strlen( $prefix ) !== 3 ) {
			    return false;
		    }

		    $decrypted = $this->decrypt_string( $encrypted, $prefix );

		    return $decrypted === home_url();
	    }
    }

    new WPSafelink_Settings();

endif;
